local _, A = ...

-- Selected Forever intermediate recipes. Each row describes one craft.
-- Source: https://auctionhouse.tk.gg/api/recipes (Forever client recipe records).
local function convert(item, name, profession, title, yield, mats)
    A.items[item] = name
    A.conversions[item] = {title=title, profession=profession, yield=yield, mats=mats}
end

convert(2840, "Copper Bar", "Mining", "Smelt Copper", 1, {[2770]=1})
convert(2841, "Bronze Bar", "Mining", "Smelt Bronze", 2, {[2840]=1, [3576]=1})
convert(2842, "Silver Bar", "Mining", "Smelt Silver", 1, {[2775]=1})
convert(3575, "Iron Bar", "Mining", "Smelt Iron", 1, {[2772]=1})
convert(3576, "Tin Bar", "Mining", "Smelt Tin", 1, {[2771]=1})
convert(3577, "Gold Bar", "Mining", "Smelt Gold", 1, {[2776]=1})
convert(3859, "Steel Bar", "Mining", "Smelt Steel", 1, {[3575]=1, [3857]=1})
convert(3860, "Mithril Bar", "Mining", "Smelt Mithril", 1, {[3858]=1})
convert(6037, "Truesilver Bar", "Mining", "Smelt Truesilver", 1, {[7911]=1})
convert(12359, "Thorium Bar", "Mining", "Smelt Thorium", 1, {[10620]=1})

convert(2996, "Bolt of Linen Cloth", "Tailoring", "Bolt of Linen Cloth", 1, {[2589]=2})
convert(2997, "Bolt of Woolen Cloth", "Tailoring", "Bolt of Woolen Cloth", 1, {[2592]=3})
convert(4305, "Bolt of Silk Cloth", "Tailoring", "Bolt of Silk Cloth", 1, {[4306]=4})
convert(4339, "Bolt of Mageweave", "Tailoring", "Bolt of Mageweave", 1, {[4338]=5})
convert(14048, "Bolt of Runecloth", "Tailoring", "Bolt of Runecloth", 1, {[14047]=5})

convert(3470, "Rough Grinding Stone", "Blacksmithing", "Rough Grinding Stone", 1, {[2835]=2})
convert(3478, "Coarse Grinding Stone", "Blacksmithing", "Coarse Grinding Stone", 1, {[2836]=2})
convert(3486, "Heavy Grinding Stone", "Blacksmithing", "Heavy Grinding Stone", 1, {[2838]=3})
convert(6217, "Copper Rod", "Blacksmithing", "Copper Rod", 1, {[2840]=1})
convert(6338, "Silver Rod", "Blacksmithing", "Silver Rod", 1, {[2842]=1, [3470]=2})
convert(7966, "Solid Grinding Stone", "Blacksmithing", "Solid Grinding Stone", 1, {[7912]=4})
convert(11128, "Golden Rod", "Blacksmithing", "Golden Rod", 1, {[3577]=1, [3478]=2})
convert(11144, "Truesilver Rod", "Blacksmithing", "Truesilver Rod", 1, {[6037]=1, [3486]=1})
convert(12644, "Dense Grinding Stone", "Blacksmithing", "Dense Grinding Stone", 1, {[12365]=4})
convert(16206, "Arcanite Rod", "Blacksmithing", "Arcanite Rod", 1, {[12360]=3, [12644]=1})

convert(4357, "Rough Blasting Powder", "Engineering", "Rough Blasting Powder", 1, {[2835]=1})
convert(4359, "Handful of Copper Bolts", "Engineering", "Handful of Copper Bolts", 1, {[2840]=1})
convert(4364, "Coarse Blasting Powder", "Engineering", "Coarse Blasting Powder", 1, {[2836]=1})
convert(4371, "Bronze Tube", "Engineering", "Bronze Tube", 1, {[2841]=2, [2880]=1})
convert(4375, "Whirring Bronze Gizmo", "Engineering", "Whirring Bronze Gizmo", 1, {[2841]=2, [2592]=1})
convert(4377, "Heavy Blasting Powder", "Engineering", "Heavy Blasting Powder", 1, {[2838]=1})
convert(4382, "Bronze Framework", "Engineering", "Bronze Framework", 1, {[2841]=2, [2319]=1, [2592]=1})
convert(10505, "Solid Blasting Powder", "Engineering", "Solid Blasting Powder", 1, {[7912]=2})
convert(10560, "Unstable Trigger", "Engineering", "Unstable Trigger", 1, {[3860]=1, [4338]=1, [10505]=1})
convert(10561, "Mithril Casing", "Engineering", "Mithril Casing", 1, {[3860]=3})
convert(15992, "Dense Blasting Powder", "Engineering", "Dense Blasting Powder", 1, {[12365]=2})

convert(2318, "Light Leather", "Leatherworking", "Light Leather", 1, {[2934]=3})
convert(2319, "Medium Leather", "Leatherworking", "Medium Leather", 1, {[2318]=4})
convert(4231, "Cured Light Hide", "Leatherworking", "Cured Light Hide", 1, {[783]=1, [4289]=1})
convert(4233, "Cured Medium Hide", "Leatherworking", "Cured Medium Hide", 1, {[4232]=1, [4289]=1})
convert(4234, "Heavy Leather", "Leatherworking", "Heavy Leather", 1, {[2319]=5})
convert(4236, "Cured Heavy Hide", "Leatherworking", "Cured Heavy Hide", 1, {[4235]=1, [4289]=3})
convert(4304, "Thick Leather", "Leatherworking", "Thick Leather", 1, {[4234]=6})
convert(8170, "Rugged Leather", "Leatherworking", "Rugged Leather", 1, {[4304]=6})
convert(15407, "Cured Rugged Hide", "Leatherworking", "Cured Rugged Hide", 2, {[8171]=1, [15409]=1})

convert(6371, "Fire Oil", "Alchemy", "Fire Oil", 2, {[6359]=2, [3371]=1})
convert(12360, "Arcanite Bar", "Alchemy", "Transmute: Arcanite", 1, {[12359]=1, [12363]=1})
convert(13423, "Stonescale Oil", "Alchemy", "Stonescale Oil", 2, {[13422]=1, [3372]=1})
convert(3383, "Elixir of Wisdom", "Alchemy", "Elixir of Wisdom", 1, {[785]=1, [2450]=2, [3371]=1})
convert(7071, "Iron Buckle", "Blacksmithing", "Iron Buckle", 2, {[3575]=1})
convert(4246, "Fine Leather Belt", "Leatherworking", "Fine Leather Belt", 1, {[2318]=6, [2320]=2})
-- A Salt Shaker is a reusable tool. The activated effect consumes one salt.
-- https://www.wowhead.com/forever/spell=19566/salt-shaker
convert(15409, "Refined Deeprock Salt", "Leatherworking", "Use a Salt Shaker (about 3 days between uses)", 1, {[8150]=1})

local ingredientNames = {
    [783] = "Light Hide",
    [2589] = "Linen Cloth",
    [2592] = "Wool Cloth",
    [2770] = "Copper Ore",
    [2771] = "Tin Ore",
    [2772] = "Iron Ore",
    [2775] = "Silver Ore",
    [2776] = "Gold Ore",
    [2835] = "Rough Stone",
    [2836] = "Coarse Stone",
    [2838] = "Heavy Stone",
    [2880] = "Weak Flux",
    [2934] = "Ruined Leather Scraps",
    [3371] = "Empty Vial",
    [3372] = "Leaded Vial",
    [3857] = "Coal",
    [3858] = "Mithril Ore",
    [4232] = "Medium Hide",
    [4235] = "Heavy Hide",
    [4289] = "Salt",
    [4306] = "Silk Cloth",
    [4338] = "Mageweave Cloth",
    [6359] = "Firefin Snapper",
    [7911] = "Truesilver Ore",
    [7912] = "Solid Stone",
    [8150] = "Deeprock Salt",
    [8171] = "Rugged Hide",
    [10620] = "Thorium Ore",
    [12363] = "Arcane Crystal",
    [12365] = "Dense Stone",
    [13422] = "Stonescale Eel",
    [14047] = "Runecloth",
    [15409] = "Refined Deeprock Salt",
}
for id, name in pairs(ingredientNames) do A.items[id] = name end

-- Farm coordinates mark an entry to a circuit. Collecting a named resource may take several laps.
local function destination(key, name, zone, map, x, y, note, ids)
    A.sites[key] = {name=name, zone=zone, map=map, x=x, y=y, note=note}
    for _, id in ipairs(ids) do A.farms[id] = {key} end
end

-- https://wowforever.gg/en/atlas/knowledge/objects/green-power-crystal-o164779/
destination("powercrystals", "Western crater crystal fields", "Un'Goro Crater", 1449, 25.5, 39.9,
    "Move south down the western side of the crater. Look for colored crystal clusters on the ground and interact with the colors your recipe needs.", {11184,11185,11186})
-- https://azeroth.wiki/forever/map/burning-steppes/firetail-scorpid
destination("firetails", "Firetail Scorpids", "Burning Steppes", 1428, 27.8, 57.8,
    "Patrol the western flats. Kill and loot Firetail Scorpids, then skin them for Heavy Scorpid Scales. Look for Deathlash Scorpids on the way.", {15408})
-- https://azeroth.wiki/forever/map/western-plaguelands/plague-lurker
destination("plaguelurkers", "Plague Lurkers", "Western Plaguelands", 1422, 60.5, 51.9,
    "Sweep the fields east of the Writhing Haunt for level 54–55 Plague Lurkers. The silk drops when you loot the spiders.", {14227})
-- https://bindonforever.com/npc/1958 and https://guide.wow4ever.se/en/npc/1958
destination("vilefin", "Vile Fin Tidecallers", "Silverpine Forest", 1421, 81.3, 31.5,
    "Head to the Dawning Isles in Lordamere Lake. Pull Vile Fin Tidecallers one at a time and loot them for Murloc Eyes.", {730})
-- https://azeroth.wiki/forever/map/badlands/lesser-rock-elemental
destination("rocksalt", "Lesser Rock Elementals", "Badlands", 1418, 18.8, 43,
    "Ride southeast from Kargath and work the rocky ground for Lesser Rock Elementals. Loot their bodies for Deeprock Salt.", {8150})
-- https://www.icy-veins.com/wow-forever/fishing/
destination("oilfish", "Steamwheedle fishing coast", "Tanaris", 1446, 67, 22,
    "Walk the shoreline south from Steamwheedle Port. Cast into Firefin Snapper Schools for snappers or Stonescale Eel Swarms for eels. Bring a lure.", {6359,13422})
-- https://foreverdb.net/item/7973 / https://foreverdb.net/item/5500
destination("pearls", "Steeljaw Snappers for pearls", "Tanaris", 1446, 67, 29,
    "Walk south from Steamwheedle Port and loot Steeljaw Snappers for Big-mouth Clams. Open each clam in your bags for a chance at an Iridescent, Black or Golden Pearl.", {5500,7971,13926})
-- https://foreverdb.net/item/8153
A.farms[8153] = {"tanarisherb"}
A.acquisition[8153] = "Wildvine is a bonus find when you gather Purple Lotus. Search around Tanaris ruins with Herbalism 210."
-- https://bindonforever.com/spell/17187
A.acquisition[12360] = "An Alchemist at 275 can transmute a Thorium Bar and an Arcane Crystal with a Philosopher's Stone. Allow for the 47-hour base cooldown."
A.acquisition[15409] = "At Leatherworking 250, use an engineer-made Salt Shaker on Deeprock Salt. The base cooldown is 71 hours."
A.acquisition[1206] = "Mine Tin Veins for a chance at Moss Agate."
A.acquisition[1210] = "Shadowgem can turn up with Copper or Tin Ore."
A.acquisition[7909] = "Mine Mithril Deposits for a chance at Aquamarine."
A.acquisition[7910] = "Look for Star Rubies as a secondary yield from Mithril or Thorium deposits."
A.acquisition[12363] = "Mine Rich Thorium Veins for a chance at an Arcane Crystal."
