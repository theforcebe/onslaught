local addonName, A = ...
local frame = CreateFrame("Frame")
local ready, pendingBag, retryBag = false, false, false

local function refresh()
    if A.Render then A.Render() end
end

local refreshEvents={TRADE_SKILL_DETAILS_UPDATE=true,TRADE_SKILL_DATA_SOURCE_CHANGED=true,
    TRADE_SKILL_CLOSE=true,TRADE_SKILL_SHOW=true,PLAYER_STOPPED_MOVING=true,PLAYER_REGEN_DISABLED=true}
local refreshPending=false
local function refreshPinned()
    if refreshPending or not A.char.preferences.tracked then return end
    refreshPending=true
    C_Timer.After(0,function() refreshPending=false; refresh() end)
end

local function updateSkills(announce)
    local before = A.char.skills or {}
    A.ReadSkills()
    if not announce then return end
    for name, previous in pairs(before) do
        local rank = A.Skill(name)
        local guide = A.guides[name]
        if guide and rank > previous.rank then
            local oldIndex = A.ActiveIndex(guide, previous.rank)
            local nextIndex = A.ActiveIndex(guide, rank)
            local trainedCap=A.char.skills[name].cap
            local atCap=rank>=trainedCap and rank<guide[#guide].to
            local capText=name=="Lockpicking" and "Gain a character level to raise your cap." or "Unlock the next profession rank before continuing."
            if oldIndex and oldIndex ~= nextIndex then
                local last=A.lastRecipe and A.lastRecipe[name]
                local bags, alts = A.Inventory()
                local source = guide[oldIndex]
                local title = last and last.from==source.from and last.title
                    or A.StepPlan(name,source,previous.rank,previous.cap,bags,alts).recipe.title
                local nextTitle = "Guide complete."
                if nextIndex then
                    nextTitle = "Next: " .. A.StepPlan(name, guide[nextIndex], rank, A.char.skills[name].cap, bags, alts).recipe.title .. "."
                end
                if atCap then nextTitle=capText .. " " .. nextTitle end
                local verb = guide[oldIndex].crafts and ("Stop making " .. title .. ". ") or ""
                local message = name .. " " .. rank .. ". " .. verb .. nextTitle
                A.Print(message)
                if UIErrorsFrame then UIErrorsFrame:AddMessage(message, 1, 0.84, 0.48) end
                if name == A.Selected() then
                    A.preview, A.detail = nil, nil
                    if A.LiveStepChanged then A.LiveStepChanged() end
                end
            elseif atCap and previous.rank<trainedCap then
                local message=name .. " " .. rank .. ". " .. capText
                A.Print(message)
                if UIErrorsFrame then UIErrorsFrame:AddMessage(message, 1, 0.84, 0.48) end
            end
        end
    end
end

local function login()
    if not A.Identify() then return end
    A.ReadBags()
    updateSkills(false)
    if not ready then
        ready = true
        if not A.char.preferences.introduced then
            A.Print("Type /ptrail to open your profession guide.")
            A.char.preferences.introduced = true
        end
    end
    refresh()
end

function A.RefreshSkillProgress()
    updateSkills(true)
    refresh()
end

frame:SetScript("OnEvent", function(_, event, arg)
    if event == "ADDON_LOADED" then
        if arg == addonName then A.InitDB() end
    elseif event == "PLAYER_LOGIN" or event == "PLAYER_ENTERING_WORLD" then
        login()
    elseif ready and event == "SKILL_LINES_CHANGED" then
        updateSkills(true)
        refresh()
    elseif ready and event == "CHAT_MSG_SKILL" then
        -- Some skill messages arrive before the skill table changes. Read the
        -- actual rank on the next frame. Duplicate notifications are idempotent.
        C_Timer.After(0,function() updateSkills(true); refresh() end)
    elseif ready and event == "TRADE_SKILL_LIST_UPDATE" then
        A.ReadRecipeBook()
        refresh()
    elseif ready and event == "BAG_UPDATE_DELAYED" then
        if InCombatLockdown() then
            retryBag = true
        elseif not pendingBag then
            pendingBag = true
            C_Timer.After(0.12, function()
                pendingBag = false
                if InCombatLockdown() then retryBag = true; return end
                A.ReadBags()
                refresh()
            end)
        end
    elseif ready and event == "PLAYER_REGEN_ENABLED" then
        if retryBag then retryBag=false; A.ReadBags() end
        refresh()
    elseif ready and refreshEvents[event] then
        refreshPinned()
    elseif ready and event == "PLAYER_LOGOUT" and not InCombatLockdown() then
        A.ReadBags()
    end
end)
for _, event in ipairs({"ADDON_LOADED","PLAYER_LOGIN","PLAYER_ENTERING_WORLD","SKILL_LINES_CHANGED","CHAT_MSG_SKILL","TRADE_SKILL_LIST_UPDATE","BAG_UPDATE_DELAYED","PLAYER_REGEN_ENABLED","PLAYER_LOGOUT"}) do
    frame:RegisterEvent(event)
end
for event in pairs(refreshEvents) do frame:RegisterEvent(event) end

SLASH_PROFESSIONTRAIL1, SLASH_PROFESSIONTRAIL2 = "/ptrail", "/professiontrail"
SlashCmdList.PROFESSIONTRAIL = function(arg)
    if not A.char then return end
    local cmd = string.lower(strtrim(arg or ""))
    if cmd == "clear" then
        A.ClearNavigation()
        A.Print("Cleared the guide waypoint.")
    elseif cmd == "track" then
        A.ToggleTracking()
    elseif cmd:match("^track%s+") then
        local requested=cmd:match("^track%s+(.+)$")
        for _,name in ipairs(A.order) do
            if requested==name:lower() then A.PinTracker(name); return end
        end
        A.Print("Use a profession name, for example /ptrail track tailoring.")
    elseif cmd == "reset" then
        A.ResetPositions()
    else
        for _, name in ipairs(A.order) do
            if cmd == name:lower() then A.OpenGuide(name); return end
        end
        A.ToggleWindow()
    end
end
