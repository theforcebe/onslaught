local addonName, A = ...
A.name = addonName
A.guides, A.items, A.farms, A.sites, A.trainers = {}, {}, {}, {}, {}
A.conversions, A.sources, A.acquisition = {}, {}, {}
A.order = {"Alchemy","Blacksmithing","Enchanting","Engineering","Herbalism","Leatherworking","Mining","Skinning","Tailoring","Cooking","First Aid","Fishing","Lockpicking"}
A.skillIDs = {Alchemy=171, Blacksmithing=164, Enchanting=333, Engineering=202, Herbalism=182, Leatherworking=165, Mining=186, Skinning=393, Tailoring=197, Cooking=185, ["First Aid"]=129, Fishing=356, Lockpicking=633}
A.icons = {
    Alchemy="Trade_Alchemy", Blacksmithing="Trade_BlackSmithing", Enchanting="Trade_Engraving",
    Engineering="Trade_Engineering", Herbalism="Trade_Herbalism", Leatherworking="Trade_LeatherWorking",
    Mining="Trade_Mining", Skinning="INV_Misc_Pelt_Wolf_01", Tailoring="Trade_Tailoring",
    Cooking="INV_Misc_Food_15", ["First Aid"]="Spell_Holy_SealOfSacrifice", Fishing="Trade_Fishing",
    Lockpicking="Spell_Nature_MoonKey",
}

function A.Print(message)
    DEFAULT_CHAT_FRAME:AddMessage("|cffe8bd71Profession Trail|r  " .. message)
end

function A.InitDB()
    ProfTrailDB = ProfTrailDB or {}
    ProfTrailDB.characters = ProfTrailDB.characters or {}
    A.db = ProfTrailDB
end

function A.Identify()
    local id, name = UnitGUID("player"), UnitName("player")
    local realm, faction = GetRealmName(), UnitFactionGroup("player")
    if not id or not name or not realm or realm == "" or not faction then return end
    A.key = id
    local char = A.db.characters[id] or {bags={}, transferable={}, skills={}}
    char.region = GetCurrentRegion and GetCurrentRegion() or 0
    char.name, char.realm, char.faction = name, realm, faction
    if C_GameRules and Enum.GameRule then
        local function active(key)
            return Enum.GameRule[key] and C_GameRules.IsGameRuleActive(Enum.GameRule[key])
        end
        local pvp, rp = active("PvPRuleset"), active("RPRuleset")
        char.ruleset = active("HardcoreRuleset") and "Hardcore" or (pvp and (rp and "RP-PvP" or "PvP")) or (rp and "RP") or "PvE"
    end
    char.pool = RegionalUniqueNamesEnabled and RegionalUniqueNamesEnabled() and char.ruleset or realm
    char.preferences = char.preferences or {}
    char.preferences.options = char.preferences.options or {}
    A.db.characters[id], A.char = char, char
    return true
end

function A.Eligible(char)
    return A.char and char.pool == A.char.pool and char.ruleset == A.char.ruleset
        and char.region == A.char.region and char.faction == A.char.faction
end

function A.ReadBags()
    if not A.char or not C_Container or C_Container.GetContainerNumSlots(0) == 0 then return end
    local all, transferable = {}, {}
    local function readBag(bag)
        for slot = 1, C_Container.GetContainerNumSlots(bag) do
            local info = C_Container.GetContainerItemInfo(bag, slot)
            if info and info.itemID and info.stackCount then
                local id, count = info.itemID, info.stackCount
                all[id] = (all[id] or 0) + count
                if info.isBound == false then
                    transferable[id] = (transferable[id] or 0) + count
                end
            end
        end
    end
    for bag = 0, NUM_BAG_SLOTS or 4 do readBag(bag) end
    local reagentBag = Enum and Enum.BagIndex and Enum.BagIndex.ReagentBag
    if reagentBag and reagentBag > (NUM_BAG_SLOTS or 4) then readBag(reagentBag) end
    A.char.bags, A.char.transferable, A.char.seen = all, transferable, time()
end

function A.ReadSkills()
    if not A.char or not C_SkillInfo or C_SkillInfo.GetNumSkillLines() == 0 then return end
    local skills = {}
    for name, id in pairs(A.skillIDs) do
        local info = C_SkillInfo.GetSkillLineInfoByID(id)
        if info and info.maxRank > 0 and not info.isHeader then
            skills[name] = {rank=info.rank, cap=info.maxRank}
        end
    end
    A.char.skills = skills
end

function A.Inventory()
    local alts = {}
    for id, char in pairs(A.db.characters) do
        if id ~= A.key and A.Eligible(char) then
            for item, count in pairs(char.transferable or {}) do
                alts[item] = (alts[item] or 0) + count
            end
        end
    end
    return A.char.bags or {}, alts
end

function A.ItemName(id)
    return (C_Item and C_Item.GetItemNameByID and C_Item.GetItemNameByID(id)) or A.items[id] or ("Item " .. id)
end

function A.Skill(name)
    local s = A.char.skills and A.char.skills[name]
    return s and s.rank or 0, s and s.cap or 0
end

function A.IsForeignRecipeBook(trade)
    return (trade.IsTradeSkillLinked and trade.IsTradeSkillLinked())
        or (trade.IsTradeSkillGuild and trade.IsTradeSkillGuild())
        or (trade.IsTradeSkillGuildMember and trade.IsTradeSkillGuildMember())
        or (trade.IsNPCCrafting and trade.IsNPCCrafting())
end

function A.ReadRecipeBook()
    local api = C_TradeSkillUI
    if not api or not api.GetBaseProfessionInfo or not api.GetRecipeInfo then return end
    if A.IsForeignRecipeBook(api) then return end
    local profession = api.GetBaseProfessionInfo()
    if not profession then return end
    local name
    for n,id in pairs(A.skillIDs) do
        if profession.professionID==id or profession.professionName==n then name=n; break end
    end
    if not name or A.Skill(name)==0 then return end
    local learned = {}
    local function check(recipe)
        if not recipe.recipeID then return end
        local info = api.GetRecipeInfo(recipe.recipeID)
        if info and info.learned~=nil then learned[recipe.recipeID]=info.learned end
    end
    for _,s in ipairs(A.guides[name]) do
        check(s)
        for _,alt in ipairs(s.alternatives or {}) do check(alt) end
    end
    if next(learned) then
        A.char.recipes = A.char.recipes or {}
        A.char.recipes[name]=learned
    end
end

function A.Selected()
    local chosen = A.char.preferences.guide
    if A.guides[chosen] then return chosen end
    for _, name in ipairs(A.order) do
        if A.Skill(name) > 0 then return name end
    end
    return A.order[1]
end

function A.AsList(value)
    if type(value) == "string" then return {value} end
    return value or {}
end
