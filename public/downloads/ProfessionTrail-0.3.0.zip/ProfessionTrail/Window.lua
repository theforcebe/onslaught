local _, A = ...
local W, H, side = 832, 592, 180
local contentW = W-side-57
local ink={0.061,0.092,0.102}; local slate={0.094,0.137,0.146}
local ivory={0.94,0.91,0.80}; local gold={0.94,0.76,0.42}
local muted={0.69,0.75,0.72}; local aqua={0.51,0.84,0.78}; local amber={1,0.71,0.43}
local window, tracker, scroll, body, rail, tabs, pool, counter, cursor
local tab = "Step"
local activeRange, inspectedChar
local activeRecipe = {}
A.lastRecipe = activeRecipe

local function fill(parent, color, layer)
    local tex = parent:CreateTexture(nil, layer or "BACKGROUND")
    tex:SetAllPoints()
    tex:SetColorTexture(unpack(color))
    return tex
end
local function label(parent, size, color, justify)
    local t = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    t:SetFont(STANDARD_TEXT_FONT,size,"")
    t:SetJustifyH(justify or "LEFT")
    t:SetJustifyV("MIDDLE")
    t:SetTextColor(unpack(color or ivory))
    return t
end
local function at(obj, parent, x, y)
    obj:SetPoint("TOPLEFT",parent,"TOPLEFT",x,-y)
end
local function button(parent, caption, x, y, w, h, action)
    local b=CreateFrame("Button",nil,parent)
    b:SetSize(w,h); at(b,parent,x,y)
    b.bg=fill(b,slate)
    local hi=b:CreateTexture(nil,"HIGHLIGHT"); hi:SetAllPoints(); hi:SetColorTexture(1,1,1,0.08)
    b.text=label(b,13,ivory,"CENTER"); b.text:SetAllPoints(); b.text:SetText(caption)
    b:SetScript("OnClick",action)
    return b
end
local function position(f, key, x, y)
    f:ClearAllPoints()
    local pos=A.db[key]
    if pos then f:SetPoint("CENTER",UIParent,"CENTER",pos.x,pos.y)
    else f:SetPoint("CENTER",UIParent,"CENTER",x,y) end
end
local function movable(f, grip, key)
    f:SetMovable(true); f:SetClampedToScreen(true); grip:EnableMouse(true); grip:RegisterForDrag("LeftButton")
    grip:SetScript("OnDragStart",function() f:StartMoving() end)
    grip:SetScript("OnDragStop",function()
        f:StopMovingOrSizing()
        local x,y=f:GetCenter()
        local scale=f:GetEffectiveScale()/UIParent:GetEffectiveScale()
        local cx,cy=UIParent:GetCenter()
        A.db[key]={x=x-cx/scale,y=y-cy/scale}
    end)
end
local function newView()
    A.detail=nil
    if scroll then scroll:SetVerticalScroll(0) end
end
local function selectTab(nextTab)
    tab=nextTab; newView(); A.Render()
end
local function chooseGuide(name)
    A.char.preferences.guide=name; A.preview=nil; activeRange=nil; inspectedChar=nil
    if window and window.range then window.range.dirty=nil end
    newView(); A.Render()
end

-- Reuse row frames when bags or skills change. Only the selected tab is rendered.
local function row(text, style, onClick, tip)
    style=style or {}
    counter=counter+1
    local r=pool[counter]
    if not r then
        r=CreateFrame("Button",nil,body)
        r.bg=fill(r,slate)
        r.hi=r:CreateTexture(nil,"HIGHLIGHT"); r.hi:SetAllPoints(); r.hi:SetColorTexture(1,1,1,.06)
        r.text=label(r,14); r.num={}
        for j=1,4 do r.num[j]=label(r,13,muted,"RIGHT") end
        table.insert(pool,r)
    end
    r:ClearAllPoints(); at(r,body,0,cursor)
    local inset=style.indent or (onClick and 10 or 0)
    r.text:ClearAllPoints(); r.text:SetPoint("LEFT",r,"LEFT",inset,0)
    r.text:SetWidth(contentW-inset-(style.columns and 251 or 9))
    r.text:SetFont(STANDARD_TEXT_FONT,style.size or 14,"")
    r.text:SetTextColor(unpack(style.color or ivory))
    r.text:SetText(text or ""); r.text:SetWordWrap(true)
    local height=math.max(style.height or 20,math.ceil(r.text:GetStringHeight())+(onClick and 12 or 5))
    r:SetSize(contentW,height); r:Show(); r:EnableMouse(onClick ~= nil or tip ~= nil)
    r.bg:SetShown(style.shade or false)
    r.hi:SetShown(onClick ~= nil)
    for j,t in ipairs(r.num) do
        t:ClearAllPoints(); t:SetWidth(57); t:SetPoint("RIGHT",r,"RIGHT",-6-(4-j)*59,0)
        t:SetText(style.columns and style.columns[j] or "")
        t:SetTextColor(unpack((style.colColors and style.colColors[j]) or muted))
    end
    r:SetScript("OnClick",onClick)
    r:SetScript("OnEnter",tip and function(self)
        GameTooltip:SetOwner(self,"ANCHOR_RIGHT"); GameTooltip:SetText(tip,nil,nil,nil,nil,true); GameTooltip:Show()
    end or nil)
    r:SetScript("OnLeave",function() GameTooltip:Hide() end)
    cursor=cursor+height+(style.gap or 2)
    return r
end
local function heading(text) cursor=cursor+7; row(text,{size=16,color=gold,gap=3}) end
local function note(text) if text and text~="" then row(text,{color=muted,size=13,gap=4}) end end
local mapHook, returnFromMap
local function visit(key)
    if not A.Navigate(key) or not WorldMapFrame then return end
    if not WorldMapFrame.IsShown or not WorldMapFrame:IsShown() then return end
    if not mapHook then
        WorldMapFrame:HookScript("OnHide",function()
            if returnFromMap then
                returnFromMap=nil
                if not InCombatLockdown() then window:Show() end
            end
        end)
        mapHook=true
    end
    returnFromMap=true; window:Hide()
end
local function siteRow(key)
    local s=A.sites[key]
    if not s then return end
    local coords=s.x and s.y and string.format("  %.1f, %.1f",s.x,s.y) or ""
    row(s.name .. "  ·  " .. s.zone .. coords,{color=aqua,shade=true},function() visit(key) end,s.note)
    note(s.note)
end
local function siteList(value)
    for _,key in ipairs(A.AsList(value)) do siteRow(key) end
end

local function altDetails(id)
    local lines={}
    for key,c in pairs(A.db.characters) do
        local qty=(c.transferable or {})[id] or 0
        if key~=A.key and A.Eligible(c) and qty>0 then
            lines[#lines+1]=string.format("%s  ×%d  (%s)",c.name,qty,date("%b %d, %H:%M",c.seen))
        end
    end
    table.sort(lines)
    if #lines>0 then note("Available to send: " .. table.concat(lines,"  •  ")) end
end
local function acquire(id, qty, depth, seen)
    if seen[id] then return end
    seen[id]=true
    local conv=A.conversions[id]
    if conv then
        local parts={}
        local runs=math.ceil(qty/(conv.yield or 1))
        for input,units in pairs(conv.mats) do
            parts[#parts+1]=A.ItemName(input) .. " ×" .. (runs*units)
        end
        table.sort(parts)
        note(conv.profession .. " • " .. conv.title .. " • " .. table.concat(parts,", "))
    end
    note(A.acquisition[id])
    siteList(A.farms[id])
    if conv then
        local ids={}
        for input in pairs(conv.mats) do ids[#ids+1]=input end
        table.sort(ids)
        for _,input in ipairs(ids) do
            acquire(input,math.ceil(qty/(conv.yield or 1))*conv.mats[input],depth+1,seen)
        end
    elseif not A.farms[id] and not A.acquisition[id] then
        note("No field location is recorded for " .. A.ItemName(id) .. ".")
    end
end
local function materialList(rows, detail)
    if #rows==0 then return end
    row("Material",{size=12,color=muted,columns={"Need","Bags","Alts","Missing"}})
    for _,item in ipairs(rows) do
        local id=item.id
        row(item.name,{shade=true,columns={item.qty,item.here,item.away,item.missing},
            colColors={ivory,ivory,aqua,item.missing>0 and amber or muted}},
            function() A.detail=A.detail~=id and id or nil; A.Render() end,
            "Show sources, farming directions and alt holdings")
        if A.detail==id then
            if detail and detail[id] then
                for _,use in ipairs(detail[id]) do
                    local credit=use.credit>0 and ("  (" .. use.credit .. " made earlier)") or ""
                    note(string.format("%d–%d  %s  ×%d%s",use.first,use.last,use.title,use.used,credit))
                end
            end
            altDetails(id)
            if item.move>0 then note("Transfer " .. item.move .. " from your alts for this plan.") end
            acquire(id,math.max(1,item.missing>0 and item.missing or item.qty),0,{})
        end
    end
end

local function farmingStops(required,bags,alts)
    local raw=A.GatheringNeeds(required,bags,alts)
    if not next(raw) then return end
    heading("Farming and supply stops")
    note("Shortfalls after transfers, with craftable parts broken into ingredients. Shared stops appear first.")
    local bySite,other={},{}
    for id,n in pairs(raw) do
        local item=A.ItemName(id) .. " ×" .. n
        local keys=A.AsList(A.farms[id])
        if keys[1] and A.sites[keys[1]] then
            local key=keys[1]; bySite[key]=bySite[key] or {}; table.insert(bySite[key],item)
        else table.insert(other,item .. (A.acquisition[id] and ("  •  " .. A.acquisition[id]) or "")) end
    end
    local order={}
    for key in pairs(bySite) do table.insert(order,key) end
    table.sort(order,function(a,b)
        if #bySite[a]~=#bySite[b] then return #bySite[a]>#bySite[b] end
        return a<b
    end)
    for _,key in ipairs(order) do
        local site=A.sites[key]; table.sort(bySite[key])
        row(site.zone .. "  ·  " .. site.name,{color=aqua,shade=true},function() visit(key) end,site.note)
        note(table.concat(bySite[key],", "))
    end
    table.sort(other); for _,s in ipairs(other) do note(s) end
end

local function suppliesPage(name,guide,rank,cap,bags,alts)
    local top=guide[#guide].to
    local first=activeRange and activeRange[1] or math.max(1,rank)
    local last=activeRange and activeRange[2] or top
    heading(string.format("Material allocation  %d–%d",first,last))
    if first>=last then note("Target reached. Choose another range to plan its materials."); return end
    if activeRange and activeRange[1] then
        note("Fixed range. Choose Live to target to recalculate from your current skill as you level.")
    else
        note("Following your current skill. This allocation shrinks as you advance.")
    end
    note("Need is the estimated total to set aside. Earlier crafts supply later steps where possible. Select a material for its recipe breakdown and destinations.")
    local required,detail=A.Remaining(name,first,cap,bags,alts,last)
    if not next(required) then
        note("This range levels through field work. Select a step in Route for its location, equipment and directions.")
    else
        materialList(A.MaterialRows(required,bags,alts),detail)
        farmingStops(required,bags,alts)
    end
end
local function routePage(name, guide, rank)
    heading("Skill route")
    note("Select a band to preview the craft, materials and map locations.")
    local live=A.ActiveIndex(guide,rank)
    for i,s in ipairs(guide) do
        local tag=i==live and "   •  Current" or rank>=s.to and "   •  Done" or ""
        row(string.format("%d–%d    %s%s",s.from,s.to,s.title,tag),{shade=true,color=i==live and gold or ivory},
            function() tab="Step"; A.preview=i; newView(); A.Render() end)
    end
    heading("Guide sources")
    for _,link in ipairs(A.AsList(A.sources[name])) do note(link) end
end
local function bagsPage()
    heading("Bag snapshots")
    note("Log in to each alt once. Estimates include unbound materials in bags on the same faction and ruleset. Select a character to inspect their last snapshot.")
    local chars={}
    for key,c in pairs(A.db.characters) do
        if A.Eligible(c) then chars[#chars+1]={key=key,c=c} end
    end
    table.sort(chars,function(a,b)
        if a.key==A.key then return b.key~=A.key end
        if b.key==A.key then return false end
        return a.c.name<b.c.name
    end)
    for _,entry in ipairs(chars) do
        local c,key=entry.c,entry.key
        local stamp=c.seen and date("%b %d, %H:%M",c.seen) or "Waiting for bags"
        row(c.name .. "  ·  " .. (key==A.key and "Playing now" or stamp),{shade=true,color=aqua},function()
            inspectedChar=inspectedChar~=key and key or nil; A.Render()
        end)
        if inspectedChar==key then
            note(c.realm .. "  •  " .. c.faction .. "  •  " .. (c.ruleset or "") .. "  •  " .. stamp)
            local list={}
            for id,n in pairs(c.bags or {}) do
                if A.items[id] or A.farms[id] or A.conversions[id] then
                    local usable=key==A.key and n or ((c.transferable or {})[id] or 0)
                    list[#list+1]={name=A.ItemName(id),n=n,usable=usable}
                end
            end
            table.sort(list,function(a,b) return a.name<b.name end)
            if #list==0 then note("No indexed profession supplies found in these bags.") end
            for _,item in ipairs(list) do
                note(item.name .. " ×" .. item.n .. (item.usable<item.n and ("  •  transferable " .. item.usable) or ""))
            end
        end
    end
end

local function stepPage(name, guide, liveIndex, rank, cap, bags, alts)
    local index=A.preview or liveIndex
    if not index then
        heading("Guide complete")
        note("You reached " .. guide[#guide].to .. " " .. name .. ". Browse the Route tab to revisit a step.")
        return
    end
    local step=guide[index]
    local plan=A.StepPlan(name,step,A.preview and step.from or rank,cap,bags,alts)
    local r=plan.recipe
    if not A.preview then activeRecipe[name]={from=step.from,title=r.title} end
    local state=A.preview and "Route preview" or (cap>0 and "Current step" or "First step")
    row(state .. "   " .. step.from .. "–" .. step.to,{size=13,color=aqua})
    row(r.title,{size=23,color=ivory,gap=4})
    if A.preview then
        row("Return to live step",{color=aqua,shade=true},function() A.preview=nil; newView(); A.Render() end)
    elseif name=="Lockpicking" and select(2,UnitClass("player"))~="ROGUE" then
        note("Rogue class skill. You can preview its entire route here.")
    elseif rank==0 and cap==0 then
        note("Learn " .. name .. " to start tracking skill gains on this character.")
    elseif rank>=cap and cap>0 and cap<guide[#guide].to then
        row(name=="Lockpicking" and "At your current cap. Gain a character level to continue." or
            "At your trained cap. Unlock the next rank before crafting or gathering.",{color=amber})
    end
    local ranked=A.AsList(A.trainers[name])
    if not A.preview and #ranked==4 then
        local nextRank=cap==0 and 1 or cap==75 and 2 or cap==150 and 3 or cap==225 and 4
        local requiredSkill={0,50,125,200}
        local requiredLevel={1,10,20,35}
        if nextRank and rank>=requiredSkill[nextRank] then
            local key=ranked[nextRank]; local place=A.sites[key]
            if place then
                local level=nextRank>1 and ("  ·  Character level " .. requiredLevel[nextRank]) or ""
                row("Train with " .. place.name .. "  ·  " .. place.zone .. level,
                    {color=aqua,shade=true},function() visit(key) end,place.note)
            end
        end
    end
    if A.preview or cap==0 or rank<cap then
        if r.crafts then
            row(string.format("About %d craft%s left. Stop at skill %d.",plan.attempts,plan.attempts==1 and "" or "s",step.to),{color=gold})
        else
            row("Continue until skill " .. step.to .. ".",{color=gold})
        end
        if not A.preview and cap>0 and cap<step.to then
            note(name=="Lockpicking" and ("Your current cap is " .. cap .. ". Raise your character level to continue past it.") or
                ("Your current cap is " .. cap .. ". Train the next rank before continuing past it."))
        end
    end
    note(r.note)
    local book=A.char.recipes and A.char.recipes[name]
    if r.recipeID and book and book[r.recipeID]==false then
        note("Your last profession-book scan shows this recipe still needs to be learned.")
    end
    if r.pattern then note("Recipe item: " .. A.ItemName(r.pattern)) end
    if r.recipeID and not A.preview and cap>0 and C_TradeSkillUI and C_TradeSkillUI.OpenRecipe
        and C_TradeSkillUI.IsRecipeProfessionLearned and C_TradeSkillUI.IsRecipeProfessionLearned(r.recipeID) then
        row("Open recipe in profession book",{color=aqua,shade=true},function()
            if InCombatLockdown() then A.Print("Open the recipe after combat."); return end
            window:Hide()
            C_TradeSkillUI.OpenRecipe(r.recipeID)
        end)
    end
    if r.tools and #r.tools>0 then
        local names={}; for _,id in ipairs(r.tools) do names[#names+1]=A.ItemName(id) end
        note("Reusable tools: " .. table.concat(names,", "))
    end
    if #plan.options>1 then
        local key=name .. "/" .. step.from
        row((plan.manual and "Chosen recipe" or "Bag-based choice") .. "  ·  Change recipe",
            {color=aqua,shade=true},function() A.detail=A.detail~=key and key or nil; A.Render() end)
        if A.detail==key then
            local function set(choice)
                A.char.preferences.options[key]=choice; A.detail=nil; A.Render()
            end
            row("Choose automatically from known recipes and bags",{color=aqua,shade=true},function() set(nil) end)
            for i,option in ipairs(plan.options) do
                row(option.title,{color=i==plan.choice and gold or ivory,shade=true},function() set(i) end)
            end
        end
    end
    if next(plan.needs) then heading("Materials for this step"); materialList(A.MaterialRows(plan.needs,bags,alts)) end
    if r.target or step.target then heading("In the field"); siteList(r.target or step.target) end
    local start=A.preview and step.from or math.max(rank,1)
    local goal=math.min(300,(math.floor(start/75)+1)*75)
    row(string.format("Plan materials ahead   %d–%d",start,goal),{color=aqua,shade=true},function()
        activeRange={start,goal}; window.range.dirty=nil; selectTab("Supplies")
    end,"Show the total allocation across all steps in this range.")
    local nextStep=guide[index+1]
    if nextStep then
        row("At " .. step.to .. "   " .. nextStep.title,{color=aqua},function()
            A.preview=index+1; newView(); A.Render()
        end)
    end
    if A.trainers[name] then heading("Trainers and rank unlocks"); siteList(A.trainers[name]) end
end

local function buildRangeControls()
    local bar=CreateFrame("Frame",nil,window)
    bar:SetSize(contentW,32); at(bar,window,side+20,139)
    local function caption(s,x)
        local t=label(bar,13,muted); t:SetText(s); at(t,bar,x,7)
    end
    local function input(x)
        local e=CreateFrame("EditBox",nil,bar,"InputBoxTemplate")
        e:SetSize(46,22); at(e,bar,x,3); e:SetAutoFocus(false); e:SetNumeric(true); e:SetMaxLetters(3)
        e:SetScript("OnEscapePressed",function(self) self:ClearFocus() end)
        e:SetScript("OnTextChanged",function(_,user) if user then bar.dirty=true end end)
        return e
    end
    caption("From",0); bar.first=input(43); caption("to",98); bar.last=input(123)
    local function apply()
        local first,last=bar.first:GetNumber(),bar.last:GetNumber()
        local guide=A.guides[A.Selected()]
        if first<1 or last<=first or last>guide[#guide].to then
            A.Print("Choose a range from 1 to 300 with the target above the starting skill."); return
        end
        activeRange={first,last}; bar.dirty=nil
        bar.first:ClearFocus(); bar.last:ClearFocus(); newView(); A.Render()
    end
    bar.first:SetScript("OnEnterPressed",apply); bar.last:SetScript("OnEnterPressed",apply)
    button(bar,"Plan range",182,1,88,25,apply)
    button(bar,"Live to 300",278,1,95,25,function()
        activeRange=nil; bar.dirty=nil; bar.first:ClearFocus(); bar.last:ClearFocus(); newView(); A.Render()
    end)
    button(bar,"Live to target",381,1,108,25,function()
        local last=bar.last:GetNumber()
        local rank=A.Skill(A.Selected())
        if last<=math.max(1,rank) or last>300 then
            A.Print("Choose a target above your current skill, up to 300."); return
        end
        activeRange={[2]=last}; bar.dirty=nil
        bar.first:ClearFocus(); bar.last:ClearFocus(); newView(); A.Render()
    end)
    return bar
end

local function buildWindow()
    window=CreateFrame("Frame","ProfessionTrailWindow",UIParent)
    window:SetSize(W,H); window:SetFrameStrata("DIALOG"); window:EnableMouse(true)
    window:SetScale(math.min(1,(UIParent:GetWidth()-20)/W,(UIParent:GetHeight()-20)/H))
    fill(window,ink); position(window,"windowPos",0,0)
    local left=CreateFrame("Frame",nil,window); left:SetSize(side,H)
    at(left,window,0,0); fill(left,slate)
    local line=left:CreateTexture(nil,"ARTWORK"); at(line,left,0,0); line:SetSize(side,3)
    line:SetColorTexture(unpack(gold))
    local brand=label(left,20,ivory); at(brand,left,14,16); brand:SetText("Profession Trail")
    local edition=label(left,12,muted); at(edition,left,15,44); edition:SetText("Forever   •   Horde guides")
    rail={}
    local y=79
    for i,name in ipairs(A.order) do
        if i==1 or i==10 or i==13 then
            local category=label(left,12,muted); at(category,left,15,y)
            category:SetText(i==1 and "Primary professions" or i==10 and "Secondary skills" or "Class skill")
            y=y+21
        end
        local b=button(left,name,5,y,side-10,27,function() chooseGuide(name) end)
        b.text:ClearAllPoints(); b.text:SetPoint("LEFT",b,"LEFT",32,0); b.text:SetJustifyH("LEFT")
        local icon=b:CreateTexture(nil,"ARTWORK"); icon:SetSize(18,18); icon:SetPoint("LEFT",b,"LEFT",7,0)
        icon:SetTexture("Interface\\Icons\\" .. A.icons[name]); icon:SetTexCoord(.08,.92,.08,.92)
        b.dot=label(b,12,aqua); b.dot:SetPoint("RIGHT",b,"RIGHT",-6,0)
        rail[name]=b; y=y+28
        if i==9 or i==12 then y=y+9 end
    end
    local grip=CreateFrame("Frame",nil,window); grip:SetSize(W-side,60); at(grip,window,side,0)
    movable(window,grip,"windowPos")
    local leftGrip=CreateFrame("Frame",nil,left); leftGrip:SetSize(side,65); at(leftGrip,left,0,0)
    movable(window,leftGrip,"windowPos")
    window.title=label(grip,26,ivory); at(window.title,grip,20,12)
    window.subtitle=label(grip,13,muted); at(window.subtitle,grip,21,45)
    window.track=button(window,"Pin tracker",W-153,16,97,29,function() A.ToggleTracking(A.Selected()) end)
    local close=CreateFrame("Button",nil,window,"UIPanelCloseButton"); close:SetPoint("TOPRIGHT",window,"TOPRIGHT",-7,-9)
    close:SetScript("OnClick",function() window:Hide() end)
    window.progress=CreateFrame("StatusBar",nil,window)
    window.progress:SetSize(contentW,4); at(window.progress,window,side+20,73)
    fill(window.progress,slate); window.progress:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
    window.progress:SetStatusBarColor(unpack(aqua)); window.progress:SetMinMaxValues(0,300)
    tabs={}
    for i,t in ipairs({"Step","Supplies","Route","Bags"}) do
        tabs[t]=button(window,t,side+20+(i-1)*104,93,100,31,function() selectTab(t) end)
    end
    window.range=buildRangeControls()
    scroll=CreateFrame("ScrollFrame",nil,window,"UIPanelScrollFrameTemplate")
    at(scroll,window,side+20,136); scroll:SetPoint("BOTTOMRIGHT",window,"BOTTOMRIGHT",-36,23)
    body=CreateFrame("Frame",nil,scroll); body:SetSize(contentW,1); scroll:SetScrollChild(body)
    pool={}
    tinsert(UISpecialFrames,"ProfessionTrailWindow")
    window:SetScript("OnShow",function() A.Render() end)
    window:Hide()
end
local function buildTracker()
    tracker=CreateFrame("Button","ProfessionTrailTracker",UIParent)
    tracker:SetSize(400,96); tracker:SetFrameStrata("MEDIUM"); fill(tracker,ink)
    tracker:SetScale(math.min(1,(UIParent:GetWidth()-16)/400))
    position(tracker,"trackerPos",0,-145); movable(tracker,tracker,"trackerPos")
    local railLine=tracker:CreateTexture(nil,"ARTWORK"); railLine:SetWidth(3)
    railLine:SetPoint("TOPLEFT"); railLine:SetPoint("BOTTOMLEFT")
    railLine:SetColorTexture(unpack(aqua))
    tracker.title=label(tracker,12,aqua); at(tracker.title,tracker,12,8)
    tracker.stepNumber=label(tracker,12,muted,"RIGHT")
    tracker.stepNumber:SetPoint("TOPRIGHT",tracker,"TOPRIGHT",-12,-8)
    tracker.skill=label(tracker,16,ivory); at(tracker.skill,tracker,12,27)
    tracker.skill:SetWidth(376); tracker.skill:SetWordWrap(true); tracker.skill:SetMaxLines(2)
    tracker.progress=CreateFrame("StatusBar",nil,tracker)
    tracker.progress:SetPoint("TOPLEFT",tracker.skill,"BOTTOMLEFT",0,-6)
    tracker.progress:SetSize(376,5)
    fill(tracker.progress,slate)
    tracker.progress:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
    tracker.progressText=label(tracker,12,ivory)
    tracker.progressText:SetPoint("TOPLEFT",tracker.progress,"BOTTOMLEFT",0,-5)
    tracker.target=label(tracker,12,muted,"RIGHT")
    tracker.target:SetPoint("TOPRIGHT",tracker.progress,"BOTTOMRIGHT",0,-5)
    tracker.action=label(tracker,12,gold)
    tracker.action:SetPoint("TOPLEFT",tracker.progressText,"BOTTOMLEFT",0,-4)
    tracker.action:SetWidth(376); tracker.action:SetMaxLines(1)
    tracker.updateControls=A.AttachTrackerControls(tracker,{button=button,label=label,at=at,
        ink=ink,slate=slate,aqua=aqua,muted=muted,ivory=ivory,amber=amber,gold=gold})
    tracker:RegisterForClicks("LeftButtonUp","RightButtonUp")
    tracker:SetScript("OnClick",function(_,button)
        local name=A.char.preferences.tracked
        if button=="RightButton" then
            A.ToggleTracking(name)
            GameTooltip:Hide()
        else
            A.OpenGuide(name)
        end
    end)
    tracker:SetScript("OnEnter",function(self)
        GameTooltip:SetOwner(self,"ANCHOR_TOP")
        GameTooltip:SetText("Click for the full guide. Drag to move. Right-click to unpin.")
        GameTooltip:Show()
    end)
    tracker:SetScript("OnLeave",function() GameTooltip:Hide() end)
end
local function updateTracker(bags,alts)
    local name=A.char.preferences.tracked
    if not name or not A.guides[name] then if tracker then tracker:Hide() end; return end
    if not tracker then buildTracker() end
    local rank,cap=A.Skill(name)
    local guide=A.guides[name]
    local index=A.ActiveIndex(guide,rank)
    local step=guide[index or #guide]
    local span=step.to-step.from
    local done=math.max(0,math.min(span,rank-step.from))
    tracker.title:SetText(name .. "   " .. rank .. " / " .. guide[#guide].to)
    tracker.stepNumber:SetText(string.format("Step %d of %d",index or #guide,#guide))
    tracker.progress:SetMinMaxValues(0,span)
    tracker.progress:SetValue(done)
    tracker.progress:SetStatusBarColor(unpack(index and cap>0 and rank>=cap and amber or aqua))
    tracker.progressText:SetText(string.format("%d / %d skill points",done,span))
    tracker.target:SetText("Target " .. step.to)
    local plan
    if index then
        plan=A.StepPlan(name,step,rank,cap,bags,alts)
        local recipe=plan.recipe
        activeRecipe[name]={from=step.from,title=recipe.title}
        tracker.skill:SetText(recipe.title)
        if cap==0 then
            tracker.action:SetText("Learn the skill to begin")
        elseif rank>=cap then
            tracker.action:SetText(name=="Lockpicking" and "At cap • gain a character level" or "At cap • unlock the next rank")
        elseif recipe.crafts then
            tracker.action:SetText(string.format("About %d %s left",plan.attempts,plan.attempts==1 and "craft" or "crafts"))
        else
            local key=A.AsList(recipe.target or step.target)[1]
            local site=key and A.sites[key]
            tracker.action:SetText(site and site.zone or "")
        end
    else
        tracker.skill:SetText("Guide complete")
        tracker.action:SetText("Click to browse the route")
    end
    local controlsTop=27+math.ceil(tracker.skill:GetStringHeight())+6+5+5+
        math.ceil(tracker.progressText:GetStringHeight())+4+math.ceil(tracker.action:GetStringHeight())+7
    tracker:SetHeight(tracker.updateControls(name,step,rank,cap,plan,bags,alts,controlsTop)+5)
    tracker:Show()
end

function A.Render()
    if not A.char then return end
    if not (window and window:IsShown()) and not A.char.preferences.tracked then
        if tracker then tracker:Hide() end
        return
    end
    local bags,alts=A.Inventory()
    updateTracker(bags,alts)
    if not window or not window:IsShown() then return end
    local name=A.Selected(); local guide=A.guides[name]
    if not guide then return end
    local rank,cap=A.Skill(name)
    window.title:SetText(name)
    window.subtitle:SetText(A.char.name .. "  •  " .. (cap>0 and (rank .. " / " .. cap .. " trained") or "Untrained") .. "  •  Guide to " .. guide[#guide].to)
    window.progress:SetValue(rank)
    window.track.text:SetText(A.char.preferences.tracked==name and "Unpin tracker" or "Pin tracker")
    for n,b in pairs(rail) do
        b.bg:SetColorTexture(unpack(n==name and ink or slate)); b.text:SetTextColor(unpack(n==name and gold or ivory))
        local r=A.Skill(n); b.dot:SetText(r>0 and r or "")
    end
    for t,b in pairs(tabs) do b.text:SetTextColor(unpack(t==tab and gold or muted)) end
    local supplies=tab=="Supplies"
    window.range:SetShown(supplies)
    if supplies and not window.range.dirty then
        if not window.range.first:HasFocus() then window.range.first:SetNumber(activeRange and activeRange[1] or math.max(1,rank)) end
        if not window.range.last:HasFocus() then window.range.last:SetNumber(activeRange and activeRange[2] or guide[#guide].to) end
    end
    scroll:ClearAllPoints(); at(scroll,window,side+20,supplies and 175 or 136)
    scroll:SetPoint("BOTTOMRIGHT",window,"BOTTOMRIGHT",-36,23)
    counter,cursor=0,0
    if tab=="Step" then stepPage(name,guide,A.ActiveIndex(guide,rank),rank,cap,bags,alts)
    elseif supplies then suppliesPage(name,guide,rank,cap,bags,alts)
    elseif tab=="Route" then routePage(name,guide,rank)
    else bagsPage() end
    for i=counter+1,#pool do pool[i]:Hide() end
    body:SetHeight(math.max(cursor+8,scroll:GetHeight()))
    if scroll.UpdateScrollChildRect then scroll:UpdateScrollChildRect() end
    scroll:SetVerticalScroll(math.min(scroll:GetVerticalScroll(),math.max(0,body:GetHeight()-scroll:GetHeight())))
end

function A.PinTracker(name)
    if A.craftBatch and A.char.preferences.tracked~=name then A.StopCraftBatch() end
    A.char.preferences.tracked=name
    returnFromMap=nil
    if window then window:Hide() end
    A.Render()
end
function A.ToggleTracking(name)
    local pinned=A.char.preferences.tracked
    name=name or (window and window:IsShown() and A.Selected()) or pinned or A.Selected()
    if pinned~=name then A.PinTracker(name); return end
    if A.craftBatch then A.StopCraftBatch() end
    A.char.preferences.tracked=nil
    A.Render()
end
function A.LiveStepChanged()
    if tab=="Step" and scroll then scroll:SetVerticalScroll(0) end
end
function A.OpenGuide(name)
    if not window then buildWindow() end
    tab="Step"; chooseGuide(name or A.Selected()); window:Show(); window:Raise()
end
function A.ToggleWindow()
    if window and window:IsShown() then window:Hide()
    elseif window then window:Show(); window:Raise()
    else A.OpenGuide(A.Selected()) end
end
function A.ResetPositions()
    A.db.windowPos,A.db.trackerPos=nil,nil
    if window then position(window,"windowPos",0,0) end
    if tracker then position(tracker,"trackerPos",0,-145) end
    if not window then buildWindow() end
    window:Show()
end
