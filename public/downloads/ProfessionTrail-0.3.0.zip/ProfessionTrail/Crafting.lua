local _, A = ...
local issuing, watched, needsBook

local function blocked(reason)
    return {kind="blocked",limit=0,reason=reason}
end

local function canRepeat(trade)
    return type(trade.StopRecipeRepeat)=="function" and type(trade.GetRemainingRecasts)=="function"
        and type(hooksecurefunc)=="function"
end

local function knownContext(trade,name)
    local base=trade.GetBaseProfessionInfo and trade.GetBaseProfessionInfo()
    return base and (base.professionID==A.skillIDs[name] or base.parentProfessionID==A.skillIDs[name])
end

-- Rendering uses the bag snapshot. The physical click takes a fresh one and
-- checks the client's actual learned recipe, casting context and craftable count.
function A.CraftInfo(name,recipe)
    local trade=C_TradeSkillUI
    if not recipe or not recipe.recipeID or not recipe.crafts then return blocked("This step is field work.") end
    if not trade or not trade.CraftRecipe or not trade.GetRecipeInfo then return blocked("Crafting is unavailable.") end
    local rank,cap=A.Skill(name)
    if cap==0 then return blocked("Learn " .. name .. " first.") end
    if rank>=cap then return blocked("At your trained skill cap.") end
    if InCombatLockdown() then return blocked("Craft after combat.") end
    if A.IsForeignRecipeBook(trade) then return blocked("Close the shared or NPC profession book first.") end
    local held=A.CarriedCraftLimit(recipe,A.char.bags)
    if held==0 then return blocked("Bring the materials for one craft to this character.") end
    if trade.IsDataSourceChanging and trade.IsDataSourceChanging() then return blocked("Waiting for profession data.") end
    local id=recipe.recipeID
    local info=trade.GetRecipeInfo(id)
    local ownedBook=knownContext(trade,name)
    local prepare={kind="prepare",limit=1,reason="Load this character's recipe from the tracker."}
    if needsBook==id and not ownedBook and trade.OpenRecipe then return prepare end
    if not info or not info.learned or (info.recipeID and info.recipeID~=id) then
        if ownedBook and info and info.learned==false then return blocked("Learn " .. recipe.title .. " first.") end
        if not trade.OpenRecipe then return blocked("Open your profession book to load the recipe.") end
        return prepare
    end
    if info.disabled or info.craftable==false then
        if not ownedBook and trade.OpenRecipe then return prepare end
        return blocked(info.disabledReason or "The recipe is currently unavailable.")
    end
    if info.isRecraft or info.isDummyRecipe or info.isGatheringRecipe then return blocked("This recipe requires the profession book.") end
    local schematic=trade.GetRecipeSchematic and trade.GetRecipeSchematic(id,false)
    local types=Enum and Enum.TradeskillRecipeType
    if schematic and (schematic.isRecraft or (types and types.Salvage and schematic.recipeType==types.Salvage)) then
        return blocked("Choose this recipe's input in your profession book.")
    end
    if schematic and recipe.output and schematic.outputItemID and schematic.outputItemID~=recipe.output then
        return blocked("The live recipe makes a different item. Check the profession book.")
    end
    if trade.GetRecipeRequirements then
        for _,req in ipairs(trade.GetRecipeRequirements(id) or {}) do
            if req.met==false then return blocked(req.name or "A recipe requirement is missing.") end
        end
    end
    if (types and schematic and schematic.recipeType==types.Enchant) or (name=="Enchanting" and not recipe.output) then
        return {kind="target",limit=1,reason="Choose the equipment to enchant in the profession book."}
    end
    local count=trade.GetCraftableCount and trade.GetCraftableCount(id)
    if count==nil or count<=0 then
        if not ownedBook and trade.OpenRecipe then return prepare end
        return blocked("Check your tools, workstation and recipe requirements.")
    end
    local limit=math.min(held,count)
    if trade.GetRecipeCooldown then
        local cooldown,_,charges=trade.GetRecipeCooldown(id)
        if cooldown and cooldown>0 and (charges or 0)==0 then return blocked("This recipe is on cooldown.") end
        if charges and charges>0 then limit=math.min(limit,charges) end
    end
    -- Upper-bound a batch even when the server delivers the skill event after
    -- starting the next cast. Yellow/green failures can require another batch.
    local guide=A.guides[name]
    local index=guide and A.ActiveIndex(guide,rank)
    if not index then return blocked("Guide complete.") end
    local target=math.min(guide[index].to,cap)
    local points=math.max(1,info.numSkillUps or 1)
    limit=math.min(limit,math.ceil((target-rank)/points))
    if info.canCreateMultiple==false or not canRepeat(trade) or
        (trade.HasNoReagentCost and trade.HasNoReagentCost(id)) then limit=1 end
    return {kind="craft",limit=limit}
end

local function refresh()
    if A.Render then A.Render() end
end

local function release()
    A.craftBatch=nil
    refresh()
end

-- Native repeats have no addon ownership token. If a different caller submits
-- any crafting request (even the same spell), its queue takes precedence.
local function watchRequests(trade)
    if watched==trade or not hooksecurefunc then return end
    for _,method in ipairs({"CraftRecipe","CraftEnchant","CraftSalvage","RecraftRecipe","StopRecipeRepeat"}) do
        if type(trade[method])=="function" then
            hooksecurefunc(trade,method,function()
                if A.craftBatch and not issuing then release() end
            end)
        end
    end
    watched=trade
end

function A.StopCraftBatch()
    local b=A.craftBatch
    if not b then return false end
    A.craftBatch=nil
    local trade=C_TradeSkillUI
    if b.count>1 and trade and trade.StopRecipeRepeat then
        local ok=pcall(trade.StopRecipeRepeat)
        if not ok then A.Print("The client could not stop its repeats. Stop the batch in the profession book.") end
    end
    refresh()
    return true
end

local function checkTarget()
    local b=A.craftBatch
    if not b then return end
    local skill=C_SkillInfo.GetSkillLineInfoByID(A.skillIDs[b.name])
    if not skill then return end
    if skill.rank>=b.target or skill.rank>=skill.maxRank then A.StopCraftBatch() end
end

local function spellID(value)
    if issecretvalue and issecretvalue(value) then return end
    return value
end

local function casting()
    return (UnitCastingInfo and UnitCastingInfo("player")) or
        (UnitChannelInfo and UnitChannelInfo("player"))
end

local function settle(b)
    C_Timer.After(2,function()
        if A.craftBatch~=b then return end
        local trade=C_TradeSkillUI
        if not casting() and (not trade.GetRemainingRecasts or (trade.GetRemainingRecasts() or 0)<=0) then
            if not b.started then
                if not knownContext(trade,b.name) and trade.OpenRecipe then
                    needsBook=b.recipeID
                    A.Print("No cast started. Click again to load this recipe in your profession book.")
                else
                    A.Print("No cast started. Check the game's error message, tools and workstation.")
                end
            end
            release()
        else
            settle(b)
        end
    end)
end

function A.CraftBatch(name,recipe,requested,expectedFrom,expectedTo)
    if not A.char or A.craftBatch then return false end
    if InCombatLockdown() then A.Print("Craft after combat."); return false end
    A.ReadSkills()
    A.ReadBags()
    local rank,cap=A.Skill(name)
    local guide=A.guides[name]
    local index=guide and A.ActiveIndex(guide,rank)
    local step=index and guide[index]
    local bags,alts=A.Inventory()
    if not step or step.from~=expectedFrom or step.to~=expectedTo or
        A.char.preferences.tracked~=name or not recipe or
        A.StepPlan(name,step,rank,cap,bags,alts).recipe.recipeID~=recipe.recipeID then
        refresh(); A.Print("The live step changed. Check the new assignment."); return false
    end
    local state=A.CraftInfo(name,recipe)
    local trade=C_TradeSkillUI
    if state.kind=="prepare" then
        trade.OpenRecipe(recipe.recipeID)
        state=A.CraftInfo(name,recipe)
        if state.kind=="prepare" or (trade.IsDataSourceChanging and trade.IsDataSourceChanging()) then
            A.Print("Loading " .. recipe.title .. ". Click the tracker again when the recipe is ready.")
            refresh(); return false
        end
    end
    if state.kind=="target" then
        if trade.OpenRecipe then trade.OpenRecipe(recipe.recipeID) end
        A.Print(state.reason); return false
    elseif state.kind~="craft" then
        A.Print(state.reason); refresh(); return false
    end
    if casting() or (trade.GetRemainingRecasts and (trade.GetRemainingRecasts() or 0)>0) then
        A.Print("Finish the current cast or batch first."); return false
    end
    local count=math.max(1,math.min(state.limit,math.floor(tonumber(requested) or 1)))
    watchRequests(trade)
    local b={name=name,recipeID=recipe.recipeID,title=recipe.title,from=step.from,to=step.to,
        target=math.min(step.to,cap),count=count,remaining=count}
    A.craftBatch=b
    issuing=true
    local ok=pcall(trade.CraftRecipe,b.recipeID,count)
    issuing=nil
    if not ok then
        release(); A.Print("The client could not start this craft."); return false
    end
    -- Never start a cast from a timer. A failed request may emit no failure event.
    settle(b)
    refresh()
    return true
end

local events=CreateFrame("Frame")
for _,event in ipairs({"SKILL_LINES_CHANGED","CHAT_MSG_SKILL","TRADE_SKILL_CRAFT_BEGIN",
    "UPDATE_TRADESKILL_CAST_STOPPED","PLAYER_REGEN_DISABLED","PLAYER_LOGOUT"}) do events:RegisterEvent(event) end
for _,event in ipairs({"UNIT_SPELLCAST_START","UNIT_SPELLCAST_SUCCEEDED","UNIT_SPELLCAST_FAILED","UNIT_SPELLCAST_INTERRUPTED"}) do
    if events.RegisterUnitEvent then events:RegisterUnitEvent(event,"player") else events:RegisterEvent(event) end
end
events:SetScript("OnEvent",function(_,event,unit,guid,id)
    local b=A.craftBatch
    if not b then return end
    if event=="PLAYER_LOGOUT" or event=="PLAYER_REGEN_DISABLED" then
        A.StopCraftBatch()
    elseif event=="UPDATE_TRADESKILL_CAST_STOPPED" then
        local trade=C_TradeSkillUI
        if not unit and b.started and not casting() and (not trade.GetRemainingRecasts or (trade.GetRemainingRecasts() or 0)<=0) then release() end
    elseif event=="SKILL_LINES_CHANGED" or event=="CHAT_MSG_SKILL" then
        checkTarget()
        if A.craftBatch==b then C_Timer.After(0,function() if A.craftBatch==b then checkTarget() end end) end
    elseif event=="TRADE_SKILL_CRAFT_BEGIN" then
        local recipeID=spellID(unit)
        if recipeID==b.recipeID then b.started=true elseif recipeID then release() end
    elseif spellID(unit)=="player" then
        id=spellID(id)
        if id~=b.recipeID then
            if id and event=="UNIT_SPELLCAST_START" then release() end
            return
        end
        if event=="UNIT_SPELLCAST_FAILED" or event=="UNIT_SPELLCAST_INTERRUPTED" then
            A.StopCraftBatch()
        elseif event=="UNIT_SPELLCAST_SUCCEEDED" then
            b.started=true
            guid=spellID(guid)
            if guid and guid==b.lastGUID then return end
            b.lastGUID=guid
            b.remaining=b.remaining-1
            checkTarget()
            if A.craftBatch~=b then return end
            if b.remaining<=0 then release() else refresh() end
        else
            b.started=true
            checkTarget()
        end
    end
end)
