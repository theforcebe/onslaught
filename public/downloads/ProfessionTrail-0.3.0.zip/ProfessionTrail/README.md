# Profession Trail

A Horde profession leveling guide for World of Warcraft: Forever, interface 16001. Open it with **`/ptrail`**. Choose a profession and click **Pin tracker** to switch to a small, movable panel. You can also open the panel directly with **`/ptrail track tailoring`**, substituting any profession name.

The panel shows the current assignment and its progress. At Alchemy 158 in the 150–165 step, the bar reads **8 / 15 skill points**. At 165 it switches to the next assignment. Drag the tracker header to move it, click the header to open the guide, or right-click the header to unpin. Your pin returns on the same character after login.

### Use the compact tracker

- **Read the material checklist.** **Account** includes your current bags plus transferable stock in eligible alt snapshots. **Character** counts your current bags. **Needed Amount** estimates the total for the rest of this step. A checkmark appears when the account covers that material. An amber Character count means an alt can supply some or all of the difference. Hover over the row for the amount to transfer.
- **Find a farming spot.** Click a material row to expand its farms or vendors. For an intermediate with no direct source, the tracker lists destinations for its ingredients. Select a location to set TomTom's arrow and minimap pin while leaving the world map closed. Gathering assignments also show their destination directly. If TomTom is unavailable, the tracker uses Blizzard's waypoint or world map.
- **Craft from the tracker.** Click the highlighted recipe name or **Craft 1** when your character carries one craft's ingredients. Use **+** and **−** to choose the number of crafts before starting. Shift-click **+** for the current maximum. Each click on the recipe or Craft button starts the displayed batch. The game can open its profession book to load uncached recipe data or ask you to choose an item for an enchant. If the data finishes loading after the click, click the tracker again.
- **Stop at the skill target.** The tracker limits batches using carried reagents, the client's craftable count, and the remaining points to the step or trained cap. It cancels its pending repeats when the live skill reaches that target. A cast the server already started can finish. **Stop queue** cancels pending repeats early. If some crafts yield no skill, the tracker shows the remaining points and you can start another batch.

## Follow a guide

- **Step** reads your character's skill directly. Craft or gather until the displayed skill target. As soon as you reach it, a message identifies the next step and the tracker updates. You control batches started separately in Blizzard's profession book.
- **Supplies** shows the estimated quantity to reserve, your bag quantity, eligible alt stock, and the remaining shortage. Enter any start and target from 1 to 300 and click **Plan range** to see the entire allocation in advance. **Live to target** keeps the end you entered and advances the start with your skill. **Live to 300** follows the rest of the guide.
- **Route** shows every skill band and lets you preview its recipe, trainer, and farm. **Return to live step** brings you back to your character's current assignment.
- **Bags** shows the last snapshot from each eligible character. Click a character to see its indexed profession materials. Open the addon on any character to browse. Simply logging in with it enabled is enough to record bags.

### A material allocation in practice

With the default Tailoring recipes, a fixed plan for **150–185** estimates **32 Silken Thread**. Ten Crimson Silk Belts use ten thread. The intervening Crimson Silk Vests use Fine Thread. About eleven Crimson Silk Pantaloons use another 22 Silken Thread. If your character has eight Silken Thread and an eligible alt holds ten, the plan shows **14 missing**. Click the thread row to see its uses, which alt can send it, and where to find a supplier.

Skill-ups can vary. The planner estimates attempts from each recipe's skill-color thresholds and recalculates from the measured rank. Earlier bolts, powders and other outputs can supply later steps. One-time quest materials appear when the corresponding rank is still locked. Tools, recipe patterns, and special prerequisites are called out in their steps. Counts cover route reagents and the listed one-time material requirements.

When a skill band has multiple suitable recipes, the guide considers learned recipes from your last personal profession-book scan, the crafts you can make from your bags, and transferable alt stock. Open your profession book to refresh learned recipe information. **Change recipe** lets you choose a particular recipe or switch back to automatic selection. A choice is saved per character and skill band.

### Farm and navigate

Click a material for sources and directions. Click a farm, trainer, supplier, or quest contact to open the zone map and mark the destination. A pin can mark a circuit entrance or a hunting area. Its directions describe what to look for after arrival. In **Supplies**, the farming and supply stops group missing ingredients by destination so you can collect several on one visit.

TomTom provides a world-map pin, minimap pin and directional arrow when enabled. The addon also supports Blizzard waypoints and a separate world-map marker when a Blizzard waypoint is already occupied. `/ptrail clear` removes the guide's destination.

## Coverage and storage

The English guide covers Alchemy, Blacksmithing, Enchanting, Engineering, Herbalism, Leatherworking, Mining, Skinning, Tailoring, Cooking, First Aid, Fishing and rogue Lockpicking from 1 to 300. Its 165 skill bands include 83 alternate choices. Directions favor Horde characters on PvE rulesets. Some higher-level gathering circuits use Classic terrain references.

Snapshots update on login and bag changes. The planner counts carried items for the active character and unbound materials from eligible alts. The grouping uses region, faction and Forever ruleset, with realm scoping when regional names are unavailable. Bank, mail and auction inventories are outside these counts. The **Bags** tab shows snapshot times, and a fresh login updates each alt. The guide and its data run locally without market feeds or auction scans.

## Install or move the addon

Extract the ZIP into `World of Warcraft/_forever_/Interface/AddOns/`. The resulting folder must be `ProfessionTrail`, with `ProfessionTrail.toc` immediately inside. Enable **Profession Trail** on the character-selection AddOns screen and enter the world. If the client was running during installation, restart it if the addon does not appear.

- `/ptrail` opens or closes the guide. `/professiontrail` is an alias.
- `/ptrail tailoring` opens the live Tailoring guide. Other profession names also work.
- `/ptrail track tailoring` shows the compact Tailoring tracker directly. The same command works for multiword names such as `/ptrail track first aid`.
- `/ptrail track` toggles the selected guide's tracker while the guide is open. With the guide closed it dismisses the active tracker or pins the selected profession.
- `/ptrail reset` recenters the guide and tracker.

## Sources and verification

Guide routes draw on [Mobalytics' Forever profession guides](https://mobalytics.gg/wow-forever/professions), including Crix's crafting guides and [Rogue's Diary on Lockpicking](https://mobalytics.gg/wow-forever/profile/roguesdiary/guides/rogue-lockpicking-guide). Recipe, skill-color, and location facts were checked against [Forever Codex](https://forever-codex.com/professions/), [WoW-Professions' Forever guides](https://www.wow-professions.com/forever/tailoring-leveling-guide), and [Forever recipe data](https://auctionhouse.tk.gg/data/). Each profession's Route tab includes its source addresses.

The release targets the installed Forever 1.60.1 client. Validation included Lua 5.1 execution in TOC order, simulated profession and bag events, UI click-throughs, allocation arithmetic, navigation behavior, and map-ID checks against Questie's installed Forever data. Actual in-game rendering and travel remain to be verified on a logged-in character.
