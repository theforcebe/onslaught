local _, A = ...
local floor, ceil, min, max = math.floor, math.ceil, math.min, math.max

function A.CarriedCraftLimit(recipe,bags)
    local limit=math.huge
    for id,units in pairs(recipe.mats or {}) do
        limit=min(limit,floor((bags[id] or 0)/units))
    end
    return limit
end

function A.ActiveIndex(guide, rank)
    for i, step in ipairs(guide) do
        if rank < step.to then return i end
    end
end

local function copy(t)
    local result = {}
    for k, v in pairs(t or {}) do result[k] = v end
    return result
end

local function attempts(step, recipe, rank, target)
    if not recipe.crafts then return 0 end
    local last = min(step.to, target or step.to)
    local left = max(0, last - max(step.from, rank))
    if recipe.yellow and recipe.gray and recipe.gray > recipe.yellow and last <= recipe.gray then
        local expected = 0
        for point = max(step.from,rank), last - 1 do
            expected = expected + max(1, (recipe.gray-recipe.yellow) / (recipe.gray-point))
        end
        return ceil(expected)
    end
    return ceil(left * recipe.crafts / (step.to - step.from))
end

local function inputs(step, recipe, count, cap)
    local result = {}
    for id, units in pairs(recipe.mats or {}) do result[id] = units * count end
    if step.onceMats and cap <= (step.onceCap or 225) then
        for id, units in pairs(step.onceMats) do result[id] = (result[id] or 0) + units end
    end
    return result
end

-- Fraction of the interval craftable, limited by the first missing reagent.
local function readiness(step, recipe, rank, bags, alts, target)
    local count = attempts(step, recipe, rank, target)
    if count == 0 then return 0, 0 end
    local here, total = count, count
    for id, units in pairs(recipe.mats or {}) do
        here = min(here, floor((bags[id] or 0) / units))
        total = min(total, floor(((bags[id] or 0) + (alts[id] or 0)) / units))
    end
    return here / count, total / count
end

function A.StepPlan(name, step, rank, cap, bags, alts, target)
    local options = {step}
    for _, alt in ipairs(step.alternatives or {}) do options[#options+1] = alt end
    local override = A.char.preferences.options[name .. "/" .. step.from]
    local batch=A.craftBatch
    if batch and batch.name==name and batch.from==step.from then
        for i,option in ipairs(options) do
            if option.recipeID==batch.recipeID then override=i; break end
        end
    end
    local best = 1
    if override and options[override] then
        best = override
    elseif #options > 1 then
        local book=A.char.recipes and A.char.recipes[name]
        local liveRank=A.Skill(name)
        local function learned(recipe)
            if not book or liveRank<step.from or liveRank>=step.to then return 0 end
            if book[recipe.recipeID]==true then return 1 end
            if book[recipe.recipeID]==false then return -1 end
            return 0
        end
        local hi, hiTotal = readiness(step, step, rank, bags, alts, target)
        local known=learned(step)
        for i = 2, #options do
            local localReady, allReady = readiness(step, options[i], rank, bags, alts, target)
            local k=learned(options[i])
            if k>known or (k==known and (localReady > hi or (localReady == hi and allReady > hiTotal))) then
                best, hi, hiTotal = i, localReady, allReady
                known=k
            end
        end
    end
    local recipe = options[best]
    local count = attempts(step, recipe, rank, target)
    return {recipe=recipe, attempts=count, needs=inputs(step,recipe,count,cap), options=options,
        choice=best, manual=override ~= nil}
end

-- Credit only outputs earned before the input is needed. This keeps later crafts
-- from paying for earlier steps and allows earlier bolts/powders to carry forward.
function A.Remaining(name, rank, cap, bags, alts, target)
    target = target or 300
    local earned, required, stock, transfers = {}, {}, copy(bags), copy(alts)
    local detail = {}
    for _, step in ipairs(A.guides[name]) do
        if step.to > rank and step.from < target then
            local plan = A.StepPlan(name, step, rank, cap, stock, transfers, target)
            for id, needed in pairs(plan.needs) do
                local reuse = min(earned[id] or 0, needed)
                earned[id] = (earned[id] or 0) - reuse
                required[id] = (required[id] or 0) + needed - reuse
                detail[id] = detail[id] or {}
                table.insert(detail[id], {first=max(rank,step.from),last=min(target,step.to),
                    title=plan.recipe.title,used=needed,credit=reuse})
                local fromBag = min(stock[id] or 0, needed)
                stock[id] = (stock[id] or 0) - fromBag
                transfers[id] = max(0, (transfers[id] or 0) - (needed - fromBag))
            end
            local id = plan.recipe.output
            if id then
                local made = plan.attempts * (plan.recipe.yield or 1)
                earned[id] = (earned[id] or 0) + made
                stock[id] = (stock[id] or 0) + made
            end
        end
    end
    return required, detail
end

-- Reserve held ingredients once across the entire range. Convert only the
-- remaining shortage, rounding up whole batches and retaining surplus output.
function A.GatheringNeeds(required, bags, alts)
    local held, raw = copy(bags), {}
    for id,n in pairs(alts) do held[id]=(held[id] or 0)+n end
    local function consume(id,n,seen)
        local used=min(n,held[id] or 0)
        held[id]=(held[id] or 0)-used
        n=n-used
        if n<=0 then return end
        local conv=A.conversions[id]
        if not conv or A.farms[id] or seen[id] then raw[id]=(raw[id] or 0)+n; return end
        seen[id]=true
        local yield=conv.yield or 1
        local batches=ceil(n/yield)
        for input,units in pairs(conv.mats) do consume(input,batches*units,seen) end
        held[id]=held[id]+batches*yield-n
        seen[id]=nil
    end
    for id,n in pairs(required) do consume(id,n,{}) end
    return raw
end

function A.MaterialRows(required, bags, alts)
    local rows = {}
    for id, qty in pairs(required or {}) do
        if qty > 0 then
            local here, away = bags[id] or 0, alts[id] or 0
            rows[#rows+1] = {id=id, name=A.ItemName(id), qty=qty, here=here, away=away,
                move=min(away,max(0,qty-here)), missing=max(0,qty-here-away)}
        end
    end
    table.sort(rows, function(a,b)
        if (a.missing > 0) ~= (b.missing > 0) then return a.missing > 0 end
        if (a.move > 0) ~= (b.move > 0) then return a.move > 0 end
        if a.name ~= b.name then return a.name < b.name end
        return a.id < b.id
    end)
    return rows
end
