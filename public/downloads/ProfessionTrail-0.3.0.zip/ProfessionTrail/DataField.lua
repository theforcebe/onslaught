-- Percentage coordinates use the Forever outdoor UiMapIDs. Farm pins mark an
-- approach or the start of a circuit. Individual resources respawn and move.
local _, A = ...
local zones = {
    [1411]="Durotar", [1412]="Mulgore", [1413]="The Barrens",
    [1417]="Arathi Highlands", [1418]="Badlands", [1420]="Tirisfal Glades",
    [1421]="Silverpine Forest", [1422]="Western Plaguelands",
    [1423]="Eastern Plaguelands", [1424]="Hillsbrad Foothills",
    [1425]="The Hinterlands", [1427]="Searing Gorge", [1428]="Burning Steppes",
    [1434]="Stranglethorn Vale", [1435]="Swamp of Sorrows",
    [1440]="Ashenvale", [1442]="Stonetalon Mountains", [1443]="Desolace",
    [1444]="Feralas", [1445]="Dustwallow Marsh", [1446]="Tanaris",
    [1447]="Azshara", [1448]="Felwood", [1449]="Un'Goro Crater", [1452]="Winterspring",
    [1454]="Orgrimmar", [1456]="Thunder Bluff", [1458]="Undercity",
}
local function site(key, name, map, x, y, note)
    A.sites[key] = {name=name, zone=zones[map], map=map, x=x, y=y, note=note}
end

-- Horde profession ranks. Rank describes the skill a trainer teaches.
-- Coordinates checked against the author's in-game pins at
-- www.wow-professions.com/forever/<profession>-trainers.
site("whuut","Whuut",1454,55.8,33.1,"Learn Apprentice Alchemy in Yelmak's Alchemy and Potions in the Drag.")
site("yelmak","Yelmak",1454,56.7,33,"Journeyman Alchemy, upstairs in the alchemy shop in the Drag.")
site("halsey","Doctor Herbert Halsey",1458,47.9,73.1,"Expert Alchemy in the Apothecarium. Enter the underground district from the city's inner ring.")
site("rogvar","Rogvar",1435,48.5,55.8,"Artisan Alchemy in Stonard. Look upstairs in the alchemy building.")
site("ugthok","Ug'thok",1454,80.8,23.7,"Learn Apprentice Blacksmithing at the smithy in the Valley of Honor.")
site("snarl","Snarl",1454,79.6,23.2,"Journeyman Blacksmithing at the Valley of Honor forge.")
site("saru","Saru Steelfury",1454,82.3,23,"Expert Blacksmithing in the Valley of Honor. Bring your hammer.")
site("brikk","Brikk Keencraft",1434,29,75.5,"Artisan Blacksmithing at the forge in Booty Bay. Take the boat from Ratchet.")
site("jhag","Jhag",1454,53.5,38.4,"Learn Apprentice Enchanting in the Drag, near Kithas and Godan.")
site("godan","Godan",1454,53.9,38.4,"Journeyman Enchanting in Godan's Runeworks in the Drag.")
site("hgarth","Hgarth",1442,49.2,57.1,"Expert Enchanting. Take the path up from Sun Rock Retreat to the hut above the town.")
site("annora","Uldaman entrance for Annora",1418,44.5,12.2,"Dungeon approach. Enter Uldaman and clear the scorpions in her chamber beyond the Map Chamber to reveal the Artisan Enchanting trainer. Bring materials to train further recipes while inside.")
site("thund","Thund",1454,75.9,24.4,"Learn Apprentice Engineering in the Valley of Honor workshop.")
site("nogg","Nogg",1454,75.8,25.4,"Journeyman Engineering. Look inside Nogg's Machine Shop in the Valley of Honor.")
site("roxxik","Roxxik",1454,76,25.1,"Expert Engineering inside the Valley of Honor workshop.")
site("buzzek","Buzzek Bracketswing",1446,52.3,27.7,"Artisan Engineering. Enter Gadgetzan and look for the engineering workshop.")
site("kamari","Kamari",1454,63.2,44.6,"Learn Apprentice Leatherworking near the tanners in the Drag.")
site("karolek","Karolek",1454,62.8,44.3,"Journeyman Leatherworking. Look in the Drag beside the skinning trainer.")
site("una","Una",1456,41.7,42.6,"Expert Leatherworking at Thunder Bluff Armorers on the middle rise.")
site("hahrana","Hahrana Ironhide",1444,74.4,43.1,"Artisan Leatherworking. At Camp Mojache, enter the building across from the inn.")
site("snang","Snang",1454,62.9,49.4,"Learn Apprentice Tailoring in the Drag, beside Magar's shop.")
site("magar","Magar",1454,63.5,50,"Journeyman Tailoring in Magar's Cloth Goods in the Drag.")
site("josef","Josef Gregorian",1458,70.8,30.6,"Expert Tailoring at the shop in the Magic Quarter.")
site("daryl","Daryl Stack",1424,63.7,20.8,"Artisan Tailoring. Find the tailor in Tarren Mill by the church.")
site("makaru","Makaru",1454,73.1,26.3,"Mining ranks in the Valley of Honor. Gorina sells a Mining Pick beside the trainer. Smelt at the forge.")
site("jandi","Jandi",1454,55.5,39.7,"Herbalism ranks. Go upstairs inside the herb shop in the Drag.")
site("thuwd","Thuwd",1454,63.2,45.4,"Skinning ranks in the Drag. Buy a Skinning Knife from Tamar nearby.")
site("aska","Aska Mistrunner",1456,50.8,52.9,"Cooking trainer on Thunder Bluff's central rise. Naal sells recipes and supplies nearby.")
site("harn","Harn Longcast",1412,46.7,59.2,"At Bloodhoof Village on Stonebull Lake. Buy the Brilliant Smallfish and Longjaw Mud Snapper recipes, a pole and lures.")
site("naal","Naal Mistrunner",1456,51.4,52.7,"Cooking supplies near Aska. Buy Recipe: Bristle Whisker Catfish here.")
site("wulan","Wulan",1443,26.1,69.7,"Shadowprey Village. Buy and read Expert Cookbook when Cooking reaches 125.")
site("kelsey","Kelsey Yance",1434,28.2,74.4,"Enter the Old Port Authority at the end of Booty Bay's ship dock. Buy the Mithril Head Trout and Filet of Redgill recipes.")
site("dirge","Dirge Quikcleave",1446,52.6,28.1,"Inside Gadgetzan's inn. Clamlette Surprise unlocks Artisan Cooking at character level 35 and skill 225.")
site("gikkix","Gikkix",1446,66.7,22.1,"On the coast at Steamwheedle Port northeast of Gadgetzan. Buy the Nightfin Soup and Poached Sunscale Salmon recipes.")
site("kah","Kah Mistrunner",1456,56.1,46.9,"Apprentice and Journeyman Fishing beside the central pond.")
site("heming","Old Man Heming",1434,27.5,77.1,"Booty Bay's fishing shop on the lower boardwalk. Buy Expert Fishing - The Bass and You at skill 125 and character level 20.")
site("nat","Nat Pagle",1445,58.5,59.9,"Swim to the island in Tidefury Cove. At Fishing 225 and character level 35, accept Nat Pagle, Angler Extreme. Return with all four fish.")
site("arnok","Arnok",1454,34.1,84.4,"Apprentice and Journeyman First Aid. Look inside the hut in the Valley of Spirits.")
site("balai","Balai Lok'Wein",1445,36.5,30.4,"In Brackenwall Village. Buy Expert First Aid - Under Wraps, Manual: Heavy Silk Bandage and Manual: Mageweave Bandage together.")
site("victor","Doctor Gregory Victor",1417,73.4,36.8,"In Hammerfall's infirmary. For Triage, use the provided bandages on critically injured patients first, then badly injured. Save 15 before six die. Return for later bandage recipes.")
site("wrenix","Wrenix the Wretched",1413,63,36.4,"Level 16 rogue quest contact north of Ratchet. Take Plundering the Plunderers and collect the tools and E.C.A.C. from the apparatus.")
A.trainers.Alchemy={"whuut","yelmak","halsey","rogvar"}
A.trainers.Blacksmithing={"ugthok","snarl","saru","brikk"}
A.trainers.Enchanting={"jhag","godan","hgarth","annora"}
A.trainers.Engineering={"thund","nogg","roxxik","buzzek"}
A.trainers.Leatherworking={"kamari","karolek","una","hahrana"}
A.trainers.Tailoring={"snang","magar","josef","daryl"}
A.trainers.Herbalism={"jandi"}
A.trainers.Mining={"makaru"}
A.trainers.Skinning={"thuwd"}
A.trainers.Cooking={"aska","wulan","dirge"}
A.trainers.Fishing={"kah","heming","nat"}
A.trainers["First Aid"]={"arnok","balai","victor"}
A.trainers.Lockpicking={"wrenix"}

-- Routes are named for terrain and landmarks; use Find Herbs / Find Minerals
-- to locate the current spawns. Mob references mark a hunting area.
site("razor","Razor Hill foothills",1411,51,43,"From Razor Hill ride north toward Drygulch Ravine and return along the rocky east face. Check cliffs for Copper Veins and Earthroot, open ground for Peacebloom, and shrubs for Silverleaf.")
site("silverpine","Southern Silverpine thickets",1421,48,64,"From the Sepulcher take the road south toward Ambermill. Loop by bushes and trees along the road for Mageroyal and Briarthorn; check the western coast for Stranglekelp.")
site("hillsherb","Tarren Mill riverbank",1424,62,22,"Follow the river south from Tarren Mill for Liferoot. Search the nearby slopes and ruins for Bruiseweed, Kingsblood and Wild Steelbloom.")
site("stvale","Grom'gol herb circuit",1434,32,30,"Ride inland from Grom'gol. Sweep the riverbanks for Liferoot, brush for Fadeleaf and the ridges on either side for Goldthorn. Check the trees for Khadgar's Whisker.")
site("tanarisherb","Desert ruins circuit",1446,51,30,"Leave Gadgetzan by the south gate. Ride toward Broken Pillar, then the scattered desert ruins; check open sand for Firebloom and ruined walls for Purple Lotus.")
site("hinterherb","Hinterlands meadows",1425,57,47,"Work the grassy clearings west of Overlook Cliffs for Sungrass. Check troll ruins for Purple Lotus and cave interiors for Ghost Mushroom once you reach 245.")
site("felherb","Felwood road and ridges",1448,51,81,"Start at Emerald Sanctuary and ride north along the valley. Search open ground for Golden Sansam and Dreamfoil, slopes for Mountain Silversage and corrupted ground for Gromsblood.")
site("blindweed","Stonard marsh channels",1435,48,55,"Leave Stonard eastward. Search the shallow channels and banks for Blindweed and Liferoot. Blindweed requires Herbalism 235.")
site("barrensherb","Crossroads savanna",1413,52,31,"Circle the open savanna west and south of the Crossroads for Mageroyal and Briarthorn. Watch for Swiftthistle collected alongside either herb.")
site("grave","Kodo Graveyard",1443,51,58,"Search among the bones in central Desolace for Grave Moss. Circle the edge before crossing the center.")
site("winterherb","Everlook snowfields",1452,60,38,"Work the snowy valley outside Everlook for Icecap and check the ridges for Mountain Silversage.")
site("tin","Tarren Mill hills",1424,60,25,"Start at Tarren Mill and circle the surrounding rocky hills. Work Tin Veins and occasional Silver Veins. Smelt at a forge between laps.")
site("iron","Hammerfall highlands",1417,72,37,"Leave Hammerfall and follow the outer rock walls. Iron Deposits and rarer Gold Veins appear along ridges and in caves. Return to the road if cave mobs outlevel you.")
site("mithril","Badlands rock faces",1418,8,47,"Start outside Kargath and follow the mountain bases around the zone. Take Mithril Deposits first and Truesilver when your skill allows.")
site("thorium","Un'Goro crater wall",1449,46,13,"Start below Marshal's Refuge. Follow the northern crater wall clockwise. Check the bases of cliffs, side gullies and cave mouths for Small Thorium; add Rich Thorium at 275.")
site("richthorium","Winterspring ridges",1452,59,37,"Leave Everlook and trace the outer ridges. Check cave entrances and Frostwhisper Gorge for Thorium. Rich Thorium can yield Arcane Crystals.")
site("light","Valley of Trials boars",1411,44,66,"Loot and skin Mottled Boars east of the Den. For Light Leather, move on to higher-level boars in Durotar once you can skin them.")
site("medium","Northwatch raptor grounds",1413,56,52,"Ride inland west of Northwatch Hold. Skin Sunscale Scytheclaws, Zhevra Chargers and nearby plainstriders. Target level 16-17 beasts first.")
site("heavy","Foothill Caverns",1424,46,32,"West of Tarren Mill, skin bears outside the yeti cave. At 160 skin level 30-32 Cave Yetis and Ferocious Yetis inside for Heavy Leather.")
site("thick","Feral Scar Vale",1444,55,56,"From Camp Mojache ride west, then south into the yeti valley. Skin Feral Scar Yetis for Thick Leather; start with the lower-level mobs.")
site("rugged","Western crater dinosaurs",1449,32,43,"Ride west from Marshal's Refuge and follow the western side of Un'Goro. Skin diemetradons and pterrordaxes for Rugged Leather.")
site("frostsaber","Frostsaber Rock",1452,50,15,"Travel north from Everlook. Skin Frostsabers and Frostsaber Stalkers around the base of the rock for Frostsaber Leather.")
site("scorpid","Tanaris scorpid flats",1446,47,43,"Search the open desert south of Gadgetzan. Skin desert scorpids for Scorpid Scales.")
site("linen","Tiragarde Keep",1411,58,57,"Head southeast from Razor Hill. Clear Kul Tiras sailors and marines in the courtyard and keep, then circle the barracks for Linen Cloth.")
site("wool","Durnholde Keep",1424,76,43,"Ride southeast from Tarren Mill. Work the Syndicate camps and courtyard for Wool Cloth, starting outside the walls if the keep is crowded.")
site("silk","Scarlet Monastery approach",1420,84,32,"Follow the road northeast from Brill. Scarlet humanoids in and around the monastery drop Silk Cloth. For a group circuit, continue into the dungeon wings.")
site("mageweave","Lost Rigger Cove",1446,72,46,"Follow the coast south of Steamwheedle Port and go through the tunnel. Loop the Southsea pirates between the tents and ships for Mageweave Cloth.")
site("runecloth","Western Plaguelands farms",1422,47,52,"Start at Dalson's Tears. Clear the undead farm workers and loop between nearby farms for Runecloth. Watch for elite patrols.")
site("felcloth","Jadefire Run",1448,43,15,"From Bloodvenom Post go north to Jadefire Run. Kill Jadefire satyrs and work around the edges of the camp for Felcloth.")
site("stonebull","Stonebull Lake",1412,46,59,"Cast from the shore at Bloodhoof Village. Save Raw Brilliant Smallfish and Raw Longjaw Mud Snapper. Harn Longcast sells a pole and both recipes.")
site("bluffpond","Thunder Bluff pond",1456,55,47,"Fish beside Kah Mistrunner on the central rise. Keep Longjaw Mud Snapper and Bristle Whisker Catfish for Cooking.")
site("sunrock","Sun Rock Retreat lake",1442,48,59,"Use the lake beside Sun Rock Retreat. Apply a lure and keep Raw Bristle Whisker Catfish for Cooking.")
site("dustfish","Brackenwall freshwater",1445,40,35,"Fish inland in the swamp southeast of Brackenwall Village. Keep Raw Mithril Head Trout. Coastal casts have a different catch table.")
site("feralfish","Verdantis River",1444,63,52,"Fish the river west of Camp Mojache for redgill, nightfin (preferably at night) and sunscale salmon (preferably by day). With Nat's quest active, fish here for Feralas Ahi.")
site("lautiki","Lau'Tiki and the Sen'jin coast",1411,53.2,81.6,"Learn Fishing on the beach south of Sen'jin. Cast from the shore for Raw Slitherskin Mackerel. Zansoa sells the cooking recipe in the village.")
site("zansoa","Zansoa",1411,56.1,73.4,"Buy Recipe: Slitherskin Mackerel, a fishing pole and a lure in Sen'jin Village. Fish on the coast to the south.")
site("venom","Venomweb Vale",1420,86,51,"From Brill, go east past Brightwater Lake. Look for Vicious Night Web Spiders in the vale and cave. They can drop Small Venom Sacs.")
site("sartheris","Sar'theris Strand",1443,25,77,"With Nat's quest active, fish the sea south of Shadowprey Village for Sar'theris Striker. Check the subzone name before casting.")
site("savage","Savage Coast",1434,33,32,"With Nat's quest active, cast into the sea south of Grom'gol for Savage Coast Blue Sailfin.")
site("mistyreed","Misty Reed Strand",1435,90,72,"With Nat's quest active, fish the southeastern ocean shore for Misty Reed Mahi Mahi.")
site("egg","Tanaris roc grounds",1446,45,43,"Kill Rocs on the open sand south of Gadgetzan. Fire Rocs and Searing Rocs can also drop Giant Eggs.")
site("clam","Tanaris turtle coast",1446,67,29,"Patrol the coast south of Steamwheedle Port for Steeljaw Snappers and Surf Gliders. Open their Big-mouth Clams for Zesty Clam Meat.")
site("swiss","Innkeeper Sikewa",1443,24.1,68.2,"Buy Alterac Swiss in the Shadowprey Village inn. Bring 20 to Dirge in Gadgetzan.")
site("ship","Ratchet pirate ship",1413,65,45.5,"Follow the shore south from Ratchet and board the ship. Below deck, use Pick Lock on Buccaneer's Strongboxes.")
site("zoram","Zoram Strand",1440,13,28,"From Zoram'gar Outpost follow the naga coast north. Inspect the shore and shallows for footlockers you can open.")
site("windshear","Windshear Crag",1442,72,60,"Search the work camps and entrances to the mine on the east side of the crag. Pick pockets on eligible humanoids for extra junkboxes.")
site("angor","Angor Fortress",1418,42,28,"Work the upper rooms first for Battered Footlockers. At 175 descend for Dented Footlockers. Dark Iron dwarves also carry junkboxes.")
site("slag","The Slag Pit",1427,49,42,"Enter the Dark Iron workings in the Cauldron. Start on the lower level; from roughly 225 check the upper galleries as well.")
site("tyr","Tyr's Hand",1423,78,78,"Approach the Scarlet compound from the west. Search buildings and camps for footlockers and pick pockets for Heavy Junkboxes. Watch the elite patrols.")
site("borya","Borya",1454,63,51.3,"Tailoring supplies in the Drag. Buy thread and dyes from the shop beside Magar.")
site("tamar","Tamar",1454,63,45.5,"Leatherworking supplies in the Drag. Buy salt, thread and a skinning knife.")
site("korgeld","Kor'geld",1454,56,34.1,"In the Drag's alchemy shop. Buy vials for potions and elixirs.")
site("sovik","Sovik",1454,75.5,25.4,"In Nogg's Machine Shop. Look here for engineering supplies and stock.")
site("sumi","Sumi",1454,82.6,24,"Blacksmithing supplies beside the Valley of Honor forge. Buy flux and coal here.")
site("kithas","Kithas",1454,53.7,38,"Enchanting supplies in the Drag. Buy Copper Rods, Simple Wood and limited-stock enchanting reagents.")
site("water","Thunder Bluff cooking supplies",1456,51.4,52.7,"Check the cooking supplier or nearby innkeeper on the central rise for Refreshing Spring Water.")

local function step(first, last, title, target, note, crafts, mats)
    return {from=first, to=last, title=title, target=target, note=note, crafts=crafts, mats=mats}
end

-- Spell, output, yield, yellow, green, gray and ingredients.
-- Forever Codex build 1.60.1.70245; ingredients also checked in Broker.
local fieldRecipes={
    ["Brilliant Smallfish"]={7751,6290,1,45,65,85,{[6291]=1}},
    ["Slitherskin Mackerel"]={7752,787,1,45,65,85,{[6303]=1}},
    ["Roasted Boar Meat"]={2540,2681,1,45,65,85,{[769]=1}},
    ["Longjaw Mud Snapper"]={7753,4592,1,90,110,130,{[6289]=1}},
    ["Bristle Whisker Catfish"]={7755,4593,1,140,160,180,{[6308]=1}},
    ["Mithril Headed Trout"]={20916,8364,1,215,235,255,{[8365]=1}},
    ["Filet of Redgill"]={18241,13930,1,265,285,305,{[13758]=1}},
    ["Nightfin Soup"]={18243,13931,1,290,310,330,{[13759]=1,[159]=1}},
    ["Poached Sunscale Salmon"]={18244,13932,1,290,310,330,{[13760]=1}},
    ["Linen Bandage"]={3275,1251,1,30,45,60,{[2589]=1}},
    ["Minor Healing Potion"]={1244431,118,1,55,75,95,{[2447]=1,[2678]=1,[3371]=1}},
    ["Heavy Linen Bandage"]={3276,2581,1,50,75,100,{[2589]=2}},
    ["Wool Bandage"]={3277,3530,1,80,115,150,{[2592]=1}},
    ["Anti-Venom"]={7934,6452,3,80,115,150,{[1475]=1}},
    ["Heavy Wool Bandage"]={3278,3531,1,115,150,185,{[2592]=2}},
    ["Silk Bandage"]={7928,6450,1,150,180,210,{[4306]=1}},
    ["Heavy Silk Bandage"]={7929,6451,1,180,210,240,{[4306]=2}},
    ["Mageweave Bandage"]={10840,8544,1,210,240,270,{[4338]=1}},
    ["Heavy Mageweave Bandage"]={10841,8545,1,240,270,300,{[4338]=2}},
    ["Runecloth Bandage"]={18629,14529,1,260,290,320,{[14047]=1}},
    ["Heavy Runecloth Bandage"]={18630,14530,1,290,320,350,{[14047]=2}},
}
local function craft(first, last, name, target, note, count)
    local data=fieldRecipes[name]
    local row=step(first,last,name,target,note,count,data[7])
    row.recipeID, row.output, row.yield=data[1], data[2], data[3]
    row.yellow, row.green, row.gray=data[4], data[5], data[6]
    A.items[row.output]=name
    return row
end

A.guides.Herbalism={
    step(1,50,"Pick Peacebloom and Silverleaf","razor","Learn Herbalism and turn on Find Herbs. Sweep clearings for Peacebloom, tree lines for Silverleaf and rock faces for Earthroot from 15."),
    step(50,70,"Add Mageroyal","barrensherb","Train Journeyman with Jandi. Follow the Crossroads grasslands and collect Mageroyal among the lower-tier herbs."),
    step(70,100,"Work the Silverpine thickets","silverpine","Add Briarthorn at 70. Follow the roadside brush south of the Sepulcher. At 85, Stranglekelp opens a coastal alternative."),
    step(100,125,"Sweep the Hillsbrad slopes","hillsherb","Once Bruiseweed opens at 100, follow the slopes out of Tarren Mill. Wild Steelbloom opens at 115 on rocky ground."),
    step(125,170,"Add Kingsblood and Liferoot","hillsherb","Train Expert with Jandi. Work flat ground for Kingsblood and river edges for Liferoot from 150. Keep the green herbs in the circuit."),
    step(170,205,"Search Grom'gol's river valley","stvale","Collect Goldthorn on ridges and Fadeleaf in brush. Add Khadgar's Whisker near trees at 185. Train Artisan at 200 before the next trip."),
    step(205,230,"Sweep Tanaris ruins","tanarisherb","Collect Firebloom across the desert and Purple Lotus beside stone ruins. This and later herb circuits use Classic terrain as the route reference."),
    step(230,270,"Gather Sungrass and Ghost Mushroom","hinterherb","Follow open clearings in the Hinterlands. Add Ghost Mushroom inside caves from 245 and Golden Sansam from 260."),
    step(270,300,"Follow Felwood's valley","felherb","Gather Dreamfoil and Golden Sansam. Add Mountain Silversage at 280 and Plaguebloom at 285. Alternate sides of the road to cover fresh ground."),
}
A.guides.Mining={
    step(1,65,"Mine copper near Razor Hill","razor","Train Mining, buy a Mining Pick and activate Find Minerals. Follow the foothills north of Razor Hill. Smelt your ore at a forge. Train Journeyman from 50."),
    step(65,125,"Work tin and silver","tin","Follow the hills around Tarren Mill for Tin Veins. Check Silver Veins at 75. Smelt copper and tin into bronze between laps while the recipe still gives skill."),
    step(125,175,"Mine iron around Hammerfall","iron","Train Expert at 125. Circle the mountain bases in Arathi Highlands for Iron Deposits. Gold Veins become available at 155."),
    step(175,245,"Sweep Badlands for mithril","mithril","Follow the cliffs out of Kargath. Train Artisan at 200 to pass 225. Add Truesilver at 230 and skip nodes still showing red."),
    step(245,275,"Work Small Thorium Veins","thorium","From Marshal's Refuge follow the crater's outer wall. Small Thorium opens at 245. Mithril still gives a chance at skill-ups early in this band."),
    step(275,300,"Add Rich Thorium Veins","thorium","Continue along the crater wall, checking cave mouths and adjacent ledges for rich veins. Winterspring is another circuit if the crater is crowded."),
}
A.guides.Skinning={
    step(1,75,"Skin Valley of Trials boars","light","Learn Skinning and keep a Skinning Knife in your bags. Loot the corpse before skinning. Work the low-level boars, then train Journeyman from 50."),
    step(75,150,"Skin Northwatch raptors","medium","Outside Northwatch Hold, skin level 16-17 beasts first and add level 18 at 80. Visit Thuwd for Expert at 125 before reaching the 150 cap."),
    step(150,160,"Clear the foothills outside the yeti cave","heavy","Start on bears and lions west of Tarren Mill. A level 30 beast needs 150 Skinning; a level 32 needs 160."),
    step(160,225,"Skin the Foothill Caverns yetis","heavy","Sweep through the cave for level 30-32 yetis. Keep the Heavy Leather and hides. Learn Artisan at 200."),
    step(225,280,"Harvest Thick Leather in Feralas","thick","Ride from Camp Mojache to Feral Scar Vale. Skin level 43-45 yetis first, then add level 46 at 230."),
    step(280,300,"Skin Un'Goro dinosaurs","rugged","Work the western side of the crater for diemetradons and pterrordaxes. These creatures also supply Rugged Leather for late Leatherworking."),
}
A.guides.Fishing={
    step(1,75,"Fish Stonebull Lake","stonebull","Learn Fishing from Uthan Stillwater in Bloodhoof Village. Equip Harn's pole and a lure. Save smallfish and mud snapper. Train Journeyman from 50 at character level 10."),
    step(75,125,"Cast in Thunder Bluff","bluffpond","Fish by Kah Mistrunner. Keep snapper and catfish for Cooking. Skill rises with successful catches, so move back to easier water if fish keep escaping."),
    step(125,205,"Read the Expert book and catch catfish","sunrock","At character level 20, buy the Expert Fishing book from Old Man Heming in Booty Bay. Fish Sun Rock Retreat's lake with a lure. Save Bristle Whisker Catfish."),
    step(205,225,"Gather inland trout in Dustwallow","dustfish","Fish in freshwater with a lure. Keep Raw Mithril Head Trout for Cooking. At skill 225 and character level 35 take Nat Pagle's quest."),
    step(225,255,"Complete Nat's quest, then catch trout","nat","Catch Ahi in Feralas, Striker at Sar'theris Strand, Blue Sailfin on the Savage Coast and Mahi Mahi at Misty Reed Strand. Return to Nat. Resume fishing Dustwallow freshwater."),
    step(255,300,"Fish Feralas for endgame catches","feralfish","Cast in the Verdantis River and keep Raw Redgill. Nightfin bite outside the afternoon, most reliably at night. Use a strong lure if catches escape."),
}
-- Quest fish are one-time catches. Their farm buttons lead to each objective.
A.guides.Fishing[5].onceMats={[16967]=1,[16968]=1,[16969]=1,[16970]=1}
A.guides.Fishing[5].onceCap=225

A.guides.Cooking={
    craft(1,50,"Brilliant Smallfish","harn","Buy Harn's two fish recipes. Cook Raw Brilliant Smallfish at a cooking fire, then keep the mud snapper for the next stage.",50),
    craft(50,100,"Longjaw Mud Snapper","harn","Train Journeyman with Aska. Use the recipe from Harn and cook your Bloodhoof and Thunder Bluff catch.",52),
    craft(100,125,"Bristle Whisker Catfish","naal","Buy Naal's recipe beside Aska in Thunder Bluff. Save additional raw catfish for the next stage.",25),
    craft(125,175,"Bristle Whisker Catfish","wulan","Buy and read Wulan's Expert Cookbook in Shadowprey Village. Pick up 20 Alterac Swiss from Innkeeper Sikewa for Artisan later. Continue cooking catfish.",95),
    craft(175,225,"Mithril Headed Trout","kelsey","Buy Recipe: Mithril Head Trout and Recipe: Filet of Redgill from Kelsey Yance in Booty Bay. Cook your inland trout to 225.",52),
    craft(225,250,"Filet of Redgill","dirge","At character level 35, turn in Clamlette Surprise to Dirge. Eggs, clam meat and cheese are a single turn-in. Cook redgill from Kelsey's recipe, or use leftover trout.",25),
    craft(250,285,"Filet of Redgill","kelsey","Use Kelsey's recipe and your Feralas catch. If your bags contain nightfin or sunscale salmon, the recipes from Gikkix give guaranteed points throughout this band.",43),
    craft(285,300,"Nightfin Soup","gikkix","Buy the soup recipe at Steamwheedle Port. Pair each nightfin with vendor water. For daytime fishing choose Poached Sunscale Salmon.",17),
}
A.guides.Cooking[1].alternatives={
    craft(1,50,"Slitherskin Mackerel","zansoa","Use the Sen'jin coastal catch. Zansoa sells the cooking recipe in the village.",50),
    craft(1,50,"Roasted Boar Meat","light","Cook your Durotar boar meat at a cooking fire. Learn the recipe with Apprentice Cooking.",50),
}
A.guides.Cooking[6].alternatives={craft(225,250,"Mithril Headed Trout","dirge","Unlock Artisan with Dirge, then finish spare inland trout. Skill points slow sharply near 250.",69)}
A.guides.Cooking[7].alternatives={
    craft(250,285,"Poached Sunscale Salmon","gikkix","Buy Gikkix's recipe. Cook your daytime Feralas catch for one point per fish in this band.",35),
    craft(250,285,"Nightfin Soup","gikkix","Buy Gikkix's recipe and vendor water. Cook your nighttime Feralas catch for one point per fish in this band.",35),
}
A.guides.Cooking[8].alternatives={
    craft(285,300,"Poached Sunscale Salmon","gikkix","Buy the recipe from Gikkix and cook your daytime Feralas catch.",17),
    craft(285,300,"Filet of Redgill","kelsey","Finish with spare Redgill. The recipe is green and takes substantially more attempts.",53),
}
A.guides.Cooking[6].onceMats={[12207]=12,[7974]=10,[8932]=20}
A.guides.Cooking[6].onceCap=225

A.guides["First Aid"]={
    craft(1,40,"Linen Bandage","arnok","Learn First Aid and make single linen bandages. Save some linen for the heavy version.",41),
    craft(40,80,"Heavy Linen Bandage","arnok","Learn the heavy pattern at 40. Train Journeyman from 50 so you can pass 75. Make short batches if the recipe turns green.",56),
    craft(80,115,"Wool Bandage","arnok","Learn Wool Bandage from Arnok. This uses one cloth per attempt. Stop once the heavy version opens.",49),
    craft(115,150,"Heavy Wool Bandage","balai","Learn the recipe from Arnok. From 125, buy Balai's Expert book plus the Heavy Silk and Mageweave manuals in Brackenwall Village.",49),
    craft(150,180,"Silk Bandage","arnok","Read the Expert book first. Learn Silk Bandage from the trainer and use single pieces of silk until 180.",42),
    craft(180,210,"Heavy Silk Bandage","balai","Read Manual: Heavy Silk Bandage from Balai. Bring the Mageweave manual along for 210.",42),
    craft(210,225,"Mageweave Bandage","balai","Read Manual: Mageweave Bandage and save the remaining cloth for after Triage.",18),
    craft(225,240,"Mageweave Bandage","victor","At character level 35, visit the infirmary in Hammerfall. Complete Triage to unlock Artisan. Keep bandaging with mageweave to 240.",24),
    craft(240,260,"Heavy Mageweave Bandage","victor","Train the heavy pattern with Doctor Gregory Victor. Save your runecloth until 260.",25),
    craft(260,290,"Runecloth Bandage","victor","Learn Runecloth Bandage from the doctor. Use single cloths and watch for the final recipe at 290.",42),
    craft(290,300,"Heavy Runecloth Bandage","victor","Return to Doctor Gregory Victor for the heavy recipe and finish the remaining ten points.",11),
}
A.guides["First Aid"][1].alternatives={craft(1,40,"Minor Healing Potion","arnok","Arnok teaches First Aid's healing potion. Buy Mild Spices from a cooking supplier and Empty Vials from an alchemy supplier.",39)}
A.guides["First Aid"][2].alternatives={craft(40,80,"Minor Healing Potion","arnok","Train Journeyman from 50. Continue turning Peacebloom, vials and spices into healing potions.",54)}
A.guides["First Aid"][3].alternatives={craft(80,115,"Anti-Venom","arnok","Train the recipe from Arnok. Substitute a Small Venom Sac for cloth on each attempt.",49)}
A.guides["First Aid"][9].alternatives={craft(240,260,"Mageweave Bandage","balai","If you have the manual and cannot get back to Hammerfall yet, continue the single-cloth pattern.",64)}
A.guides["First Aid"][11].alternatives={craft(290,300,"Runecloth Bandage","victor","If you have yet to learn the heavy version, finish with the single-cloth pattern.",24)}
A.guides.Lockpicking={
    step(1,80,"Open strongboxes on the pirate ship","ship","Rogues learn Pick Lock at level 16. Get Thieves' Tools from Wrenix's quest in Ratchet. Use the strongboxes below deck; the skill cap is five times your character level."),
    step(80,110,"Search the Zoram Strand","zoram","Travel to Zoram'gar and check the naga camps, beach and shallow water. Open eligible boxes as they appear; use pickpocketed junkboxes between spawns."),
    step(110,150,"Search Windshear Crag","windshear","Sweep the Venture Co. work camps and mine entrance. Calibrate the loop to local spawns; some boxes have a higher lock requirement."),
    step(150,175,"Pick Angor's upper rooms","angor","Enter the dwarven fortress in central Badlands. Search the courtyard and upper rooms for Battered Footlockers."),
    step(175,200,"Search Angor's lower rooms","angor","Descend into the fortress. Dented Footlockers and Sturdy Junkboxes can advance your skill from 175."),
    step(200,250,"Work the Slag Pit","slag","Inspect the lower galleries in Searing Gorge, then add the upper level around 225. Pickpocket the dwarves for additional boxes."),
    step(250,300,"Open Scarlet Footlockers","tyr","At Tyr's Hand, search the Scarlet buildings, working around elites. Heavy Junkboxes from high-level humanoids are another source of skill. Level 60 opens the full 300 cap."),
}

local moba="https://mobalytics.gg/wow-forever/guides/"
local prof="https://www.wow-professions.com/forever/"
for _, p in ipairs({"Herbalism","Mining","Skinning"}) do
    local slug=p:lower()
    A.sources[p]={moba..slug.."-profession-guide",prof..slug.."-leveling-guide",prof..slug.."-trainers"}
end
A.sources.Cooking={moba.."cooking-profession-guide",prof.."fishing-and-cooking-leveling-guide",prof.."cooking-trainers","https://forever-codex.com/professions/cooking/"}
A.sources.Fishing={moba.."fishing-profession-guide",prof.."fishing-and-cooking-leveling-guide",prof.."fishing-trainers"}
A.sources["First Aid"]={moba.."first-aid-profession-guide",prof.."first-aid-leveling-guide",prof.."first-aid-trainers","https://forever-codex.com/professions/first-aid/"}
A.sources.Lockpicking={"https://mobalytics.gg/wow-forever/profile/roguesdiary/guides/rogue-lockpicking-guide",prof.."lockpicking-leveling-guide"}

site("plagueherb","Plaguelands farmsteads",1422,47,51,"Work the ground between Dalson's Tears and the neighboring farms for Arthas' Tears. At 285 also gather Plaguebloom.")
site("deLow","Low-level greens or crafted greens",1411,58,57,"Clear the humanoid camp for spare green gear, or disenchant your own crafted greens. Required levels 1-15 yield Strange Dust or Magic Essence. Armor favors dust and weapons favor essences.")
site("deAstral","Durnholde green equipment",1424,76,43,"Disenchant eligible greens. Gear requiring levels 16-20 can yield Lesser Astral Essence, while 21-25 can yield Greater Astral Essence and Soul Dust. Weapons favor essences.")
site("deMystic","Scarlet Monastery equipment",1420,84,32,"Gather green disenchantable gear from the Scarlet wings. Required levels 26-30 can yield Lesser Mystic Essence. Levels 31-35 can yield Greater Mystic Essence and Vision Dust.")
site("deNether","Lost Rigger equipment",1446,72,46,"Farm eligible greens from Southsea pirates or bring crafted greens. Required levels 36-40 can yield Lesser Nether Essence. Levels 41-45 can yield Greater Nether Essence and Dream Dust.")
site("deRadiant","Zul'Farrak entrance",1446,39,21,"Dungeon approach. Disenchant unwanted blue items requiring levels 41-45 for Large Radiant Shards. Check the actual required level before dismantling.")
site("deBrilliant","Blackrock Mountain approach",1427,34,83,"Dungeon approach. Enchanters can turn surplus blue equipment requiring levels 46-50 into Small Brilliant Shards. Higher-level blue items can yield Large Brilliant Shards.")
site("deEternal","Scarlet equipment at Tyr's Hand",1423,78,78,"Collect eligible high-level greens or use crafted equivalents. Gear requiring level 51+ can yield Illusion Dust or Greater Eternal Essence; armor favors dust. The Scarlet mobs here include elites.")

-- Multiple choices are alternative places to acquire the same item.
local function supplies(keys, ids)
    for _, id in ipairs(ids) do A.farms[id]=keys end
end
supplies("razor",{2447,765,2449,2770,2835})
supplies("tin",{2771,2775,2836,1206})
supplies("iron",{2772,2776,2838})
supplies("mithril",{3858,7911,7912,7909})
supplies({"thorium","richthorium"},{10620,12365,12363,7910})
supplies({"razor","tin"},{1210})
supplies({"silverpine","barrensherb"},{785,2450,2452})
supplies("hillsherb",{2453,3355,3356,3357})
supplies("stvale",{3358,3818,3821})
supplies("silverpine",{3820})
supplies("blindweed",{8839})
supplies("grave",{3369})
supplies("tanarisherb",{4625,8831})
supplies("hinterherb",{8838,8845})
supplies("felherb",{8846,13463,13464,13465})
supplies("plagueherb",{8836,13466})
supplies("winterherb",{13467})
supplies("light",{2934,2318,783,769})
supplies("medium",{2319,4232})
supplies("heavy",{4234,4235})
supplies("thick",{4304,8169})
supplies("rugged",{8170,8171})
supplies("frostsaber",{15422})
supplies("scorpid",{8154})
supplies("linen",{2589})
supplies("wool",{2592})
supplies("silk",{4306})
supplies("mageweave",{4338})
supplies("runecloth",{14047})
supplies("felcloth",{14256})
supplies({"stonebull","bluffpond"},{6291,6289})
supplies({"sunrock","bluffpond"},{6308})
supplies("dustfish",{8365})
supplies("feralfish",{13758,13759,13760,16967})
supplies("lautiki",{6303})
supplies("venom",{1475})
supplies("sartheris",{16968})
supplies("savage",{16969})
supplies("mistyreed",{16970})
supplies("egg",{12207})
supplies("clam",{7974})
supplies("swiss",{8932})
supplies("water",{159})
supplies("naal",{2678})
supplies("borya",{2320,2321,2324,2325,2604,2605,4291,4340,4341,4342,6260,6261,8343,10290,14341})
supplies("tamar",{4289,7005})
supplies("korgeld",{3371,3372,8925,18256})
supplies("sumi",{2880,3466,3857})
supplies("kithas",{4470,6217,247786})
supplies("deLow",{10938,10939,10940,10978})
supplies("deAstral",{10998,11082,11083})
supplies("deMystic",{11134,11135,11137})
supplies("deNether",{11174,11175,11176})
supplies("deRadiant",{11178})
supplies("deBrilliant",{14343,14344})
supplies("deEternal",{16202,16203,16204})

-- Fallback names for the field and quest reagents before the item cache is warm.
local names={
    [769]="Chunk of Boar Meat", [2678]="Mild Spices", [3371]="Empty Vial", [2447]="Peacebloom",
    [6303]="Raw Slitherskin Mackerel", [13760]="Raw Sunscale Salmon", [1475]="Small Venom Sac",
    [159]="Refreshing Spring Water", [6291]="Raw Brilliant Smallfish", [6289]="Raw Longjaw Mud Snapper",
    [6308]="Raw Bristle Whisker Catfish", [8365]="Raw Mithril Head Trout", [13758]="Raw Redgill",
    [13759]="Raw Nightfin Snapper", [12207]="Giant Egg", [7974]="Zesty Clam Meat",
    [8932]="Alterac Swiss", [16967]="Feralas Ahi", [16968]="Sar'theris Striker",
    [16969]="Savage Coast Blue Sailfin", [16970]="Misty Reed Mahi Mahi",
    [2589]="Linen Cloth", [2592]="Wool Cloth", [4306]="Silk Cloth",
    [4338]="Mageweave Cloth", [14047]="Runecloth",
}
for id, name in pairs(names) do A.items[id]=name end
