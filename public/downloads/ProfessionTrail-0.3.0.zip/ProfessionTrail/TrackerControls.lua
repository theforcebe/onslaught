local _, A = ...

-- Prefer an item's direct sources. For crafted parts, show where to get each
-- input and keep repeated destinations grouped into a single waypoint.
local function sourcesFor(itemID)
    local result, bySite, visited = {}, {}, {}
    local function collect(id)
        if visited[id] then return end
        visited[id]=true
        local found=false
        for _,key in ipairs(A.AsList(A.farms[id])) do
            if A.sites[key] then
                found=true
                local entry=bySite[key]
                if not entry then
                    entry={key=key,items={}}
                    bySite[key]=entry
                    result[#result+1]=entry
                end
                entry.items[#entry.items+1]=A.ItemName(id)
            end
        end
        local recipe=A.conversions[id]
        if found or not recipe then return end
        local ids={}
        for input in pairs(recipe.mats) do ids[#ids+1]=input end
        table.sort(ids)
        for _,input in ipairs(ids) do collect(input) end
    end
    collect(itemID)
    return result
end

local function tip(frame)
    if not frame.tip then return end
    GameTooltip:SetOwner(frame,"ANCHOR_RIGHT")
    GameTooltip:SetText(frame.tip,nil,nil,nil,nil,true)
    GameTooltip:Show()
end
local function leave() GameTooltip:Hide() end

function A.AttachTrackerControls(t, ui)
    local left, width=12,376
    local group=CreateFrame("Frame",nil,t)
    group:SetWidth(width)
    t.materialRows,t.farmButtons={},{}
    local shown,selected,page,quantity=nil,nil,1,1

    local function makeButton(parent,title,w,callback)
        local b=ui.button(parent,title,0,0,w,24,callback)
        b:SetScript("OnEnter",tip); b:SetScript("OnLeave",leave)
        return b
    end
    local function place(widget,x,y)
        widget:ClearAllPoints(); ui.at(widget,group,x,y); widget:Show()
    end
    local function enable(b,on)
        b:SetEnabled(on); b.text:SetTextColor(unpack(on and ui.aqua or ui.muted))
    end
    local function state(name,rank,cap,plan,bags)
        if not plan or not plan.recipe.recipeID or not plan.recipe.crafts then return end
        if cap==0 then return {kind="blocked",limit=0,reason="Learn the profession to craft."} end
        if rank>=cap then return {kind="blocked",limit=0,reason="Raise your skill cap to continue."} end
        local available=A.CarriedCraftLimit(plan.recipe,bags)
        if available==0 then
            return {kind="blocked",limit=0,reason="Bring one craft’s ingredients to this character."}
        end
        local info=A.CraftInfo(name,plan.recipe)
        if info.kind=="craft" then
            local limit=math.min(available,info.limit,plan.attempts)
            return {kind=limit>0 and "craft" or "blocked",limit=limit,reason=info.reason}
        end
        return info
    end

    local function activate()
        if A.craftBatch then A.StopCraftBatch(); A.Render(); return end
        if not shown or shown.name~=A.char.preferences.tracked then return end
        if InCombatLockdown() then A.Print("Craft after combat."); return end
        local name=shown.name
        local live=C_SkillInfo.GetSkillLineInfoByID(A.skillIDs[name])
        local rank,cap=A.Skill(name)
        if not live or live.rank~=rank or live.maxRank~=cap then
            A.RefreshSkillProgress()
            return
        end
        local guide=A.guides[name]
        local index=A.ActiveIndex(guide,rank)
        if not index or guide[index].from~=shown.first then A.Render(); return end
        A.ReadBags()
        local bags,alts=A.Inventory()
        local step=guide[index]
        local plan=A.StepPlan(name,step,rank,cap,bags,alts)
        if shown.id~=plan.recipe.recipeID then
            A.Render(); A.Print("The recommended recipe changed. Check the tracker before crafting."); return
        end
        local info=state(name,rank,cap,plan,bags)
        if info and info.kind~="blocked" then
            local count=info.kind=="craft" and math.min(quantity,info.limit) or 1
            if count>0 then A.CraftBatch(name,plan.recipe,count,step.from,step.to) end
        elseif info and info.reason then
            A.Print(info.reason)
        end
        A.Render()
    end
    local function adjust(delta)
        if not shown or not shown.limit or shown.limit<1 or A.craftBatch then return end
        if IsShiftKeyDown and IsShiftKeyDown() then quantity=delta>0 and shown.limit or 1
        else quantity=math.max(1,math.min(shown.limit,quantity+delta)) end
        A.Render()
    end
    t.craftButton=makeButton(group,"Craft 1",121,activate)
    t.minus=makeButton(group,"−",26,function() adjust(-1) end)
    t.plus=makeButton(group,"+",26,function() adjust(1) end)
    t.minus.tip="Reduce batch size. Shift-click to select one."
    t.plus.tip="Increase batch size. Shift-click to select the available batch."
    t.recipeLink=CreateFrame("Button",nil,t)
    t.recipeLink:SetAllPoints(t.skill)
    t.recipeLink:SetScript("OnClick",activate)
    t.recipeLink:SetScript("OnEnter",tip); t.recipeLink:SetScript("OnLeave",leave)
    t.craftHint=ui.label(group,11,ui.muted); t.craftHint:SetWidth(180)
    t.craftHint:SetWordWrap(true)
    local columns={{"Material",0,141},{"Account",143,59},{"Character",208,68},{"Needed Amount",283,93}}
    local heads={}
    for i,col in ipairs(columns) do
        heads[i]=ui.label(group,11,ui.muted,i==1 and "LEFT" or "RIGHT"); heads[i]:SetWidth(col[3]); heads[i]:SetText(col[1])
    end
    local sourceTitle=ui.label(group,12,ui.gold); sourceTitle:SetWidth(width)
    local nextPage=makeButton(group,"More locations",width,function() page=page+1; A.Render() end)
    local function materialRow(index)
        local r=t.materialRows[index]
        if r then return r end
        r=makeButton(group,"",width,nil); r:SetHeight(23)
        r.text:ClearAllPoints(); r.text:SetPoint("LEFT",r,"LEFT",17,0); r.text:SetWidth(124)
        r.text:SetJustifyH("LEFT"); r.text:SetWordWrap(false); r.text:SetMaxLines(1)
        r.check=r:CreateTexture(nil,"ARTWORK")
        r.check:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready"); r.check:SetSize(15,15)
        r.check:SetPoint("LEFT",r,"LEFT",0,0)
        for i,key in ipairs({"account","character","needed"}) do
            local col=columns[i+1]; r[key]=ui.label(r,12,ui.ivory,"RIGHT")
            r[key]:SetWidth(col[3]); r[key]:SetPoint("LEFT",r,"LEFT",col[2],0)
        end
        r:SetScript("OnClick",function(self)
            selected=selected~=self.itemID and self.itemID or nil; page=1; A.Render()
        end)
        t.materialRows[index]=r
        return r
    end
    local function farmRow(i)
        local b=t.farmButtons[i]
        if b then return b end
        b=makeButton(group,"",width,function(self) A.Navigate(self.siteKey,true) end)
        b.text:ClearAllPoints(); b.text:SetPoint("LEFT",b,"LEFT",6,0)
        b.text:SetJustifyH("LEFT"); b.text:SetWidth(width-12); b.text:SetMaxLines(1); b.text:SetWordWrap(false)
        b.text:SetTextColor(unpack(ui.aqua))
        t.farmButtons[i]=b
        return b
    end
    return function(name,step,rank,cap,plan,bags,alts,y)
        group:ClearAllPoints(); ui.at(group,t,left,y)
        local id=plan and plan.recipe.recipeID
        if not shown or shown.name~=name or shown.first~=step.from or shown.id~=id then
            selected,page,quantity=nil,1,1
        end
        shown={name=name,first=step.from,id=id}
        local h=0
        local batch=A.craftBatch
        local info=not batch and state(name,rank,cap,plan,bags)
        local craftVisible=batch or info
        t.craftButton:SetShown(not not craftVisible); t.minus:Hide(); t.plus:Hide(); t.craftHint:Hide()
        t.recipeLink:Hide(); t.skill:SetTextColor(unpack(ui.ivory))
        if craftVisible then
            local ready=batch or info.kind~="blocked"
            place(t.craftButton,0,0); enable(t.craftButton,not not ready)
            local hint,caption
            if batch then
                caption="Stop queue"
                hint=string.format("%d queued  •  Stop at %d",batch.remaining or batch.count,batch.target)
            else
                shown.limit=info.limit or 0
                quantity=math.max(1,math.min(quantity,shown.limit))
                caption=info.kind=="target" and "Choose target" or ("Craft " .. quantity)
                hint=info.reason
                if info.kind=="craft" then
                    place(t.minus,125,0); place(t.plus,154,0)
                    enable(t.minus,quantity>1); enable(t.plus,quantity<shown.limit)
                end
                if ready then
                    t.skill:SetTextColor(unpack(ui.aqua)); t.recipeLink:Show()
                    t.recipeLink.tip=caption .. "  •  " .. plan.recipe.title
                end
            end
            t.craftButton.text:SetText(caption); t.craftButton.tip=hint or caption
            h=28
            if hint and hint~="" then
                local x=t.plus:IsShown() and 187 or 128
                t.craftHint:SetWidth(width-x); t.craftHint:SetText(hint); place(t.craftHint,x,2)
                h=math.max(h,math.ceil(t.craftHint:GetStringHeight())+7)
            end
        end
        local rows=A.MaterialRows(plan and plan.needs,bags,alts)
        table.sort(rows,function(a,b) return a.name==b.name and a.id<b.id or a.name<b.name end)
        for i,col in ipairs(columns) do
            if #rows>0 then place(heads[i],col[2],h+2) else heads[i]:Hide() end
        end
        if #rows>0 then h=h+19 end
        local expanded
        for i,item in ipairs(rows) do
            local r=materialRow(i)
            place(r,0,h); h=h+24; r.itemID=item.id
            r.text:SetText(item.name); r.text:SetTextColor(unpack(selected==item.id and ui.gold or ui.aqua))
            r.account:SetText(item.here+item.away); r.character:SetText(item.here); r.needed:SetText(item.qty)
            r.check:SetShown(item.missing==0)
            r.character:SetTextColor(unpack(item.here>=item.qty and ui.aqua or item.move>0 and ui.amber or ui.ivory))
            r.tip=item.name .. "\nSelect to see farming locations and suppliers."
            if item.move>0 then r.tip=r.tip .. "\nTransfer " .. item.move .. " from eligible alts for this step." end
            if selected==item.id then expanded=item end
        end
        for i=#rows+1,#t.materialRows do t.materialRows[i]:Hide() end
        local places={}
        if expanded then
            places=sourcesFor(expanded.id)
        elseif plan and not id then
            for _,key in ipairs(A.AsList(step.target)) do
                if A.sites[key] then places[#places+1]={key=key,items={}} end
            end
        end
        sourceTitle:Hide(); nextPage:Hide()
        if expanded or #places>0 then
            local title=expanded and ("Sources for " .. expanded.name) or "Field destination"
            if expanded and #places==0 then title=A.acquisition[expanded.id] or "No recorded location." end
            sourceTitle:SetText(title); place(sourceTitle,0,h+4); h=h+math.ceil(sourceTitle:GetStringHeight())+9
        end
        local pages=math.max(1,math.ceil(#places/3))
        if page>pages then page=1 end
        local first=(page-1)*3+1; local used=0
        for i=first,math.min(first+2,#places) do
            used=used+1
            local entry=places[i]; local site=A.sites[entry.key]; local b=farmRow(used)
            b.siteKey=entry.key
            local which=table.concat(entry.items,", ")
            local caption=site.zone .. "  ·  " .. site.name
            if expanded and which~="" and which~=expanded.name then
                caption=caption .. "\n" .. which
                b.text:SetMaxLines(2); b:SetHeight(38)
            else
                b.text:SetMaxLines(1); b:SetHeight(24)
            end
            b.text:SetText(caption)
            b.tip=(which~="" and (which .. "\n") or "") .. (site.note or site.name) ..
                string.format("\n%s  %.1f, %.1f",site.zone,site.x,site.y)
            place(b,0,h); h=h+b:GetHeight()+1
        end
        for i=used+1,#t.farmButtons do t.farmButtons[i]:Hide() end
        if pages>1 then
            nextPage.text:SetText(string.format("More locations  ·  %d of %d",page,pages))
            place(nextPage,0,h); h=h+25
        end
        group:SetHeight(math.max(1,h))
        return y+h
    end
end
