local addonName, A = ...
local tomPin, nativePin, watchedTomTom
local marker, markerSite

-- Both TomTom and C_Map expect zone-map coordinates in the range 0..1.
-- Site data uses the 0..100 coordinates players see on their maps.
local function trackWithTomTom(site, x, y)
    if not TomTom or not TomTom.AddWaypoint or not TomTom.RemoveWaypoint then return false end
    if TomTom.RegisterCallback and watchedTomTom ~= TomTom then
        TomTom.RegisterCallback(A, "WaypointRemoved", function(_, removed)
            if removed == tomPin then tomPin = nil end
        end)
        watchedTomTom = TomTom
    end
    local title = site.name .. " (" .. addonName .. ")"
    local pin = TomTom:AddWaypoint(site.map, x, y, {
        title = title, from = addonName, persistent = false, silent = true,
        crazy = true, world = true, minimap = true, cleardistance = 0,
    })
    if not pin then return false end
    -- AddWaypoint can return another owner's existing pin on a title collision.
    if pin.from == addonName then
        tomPin = pin
    elseif TomTom.SetCrazyArrow then
        TomTom:SetCrazyArrow(pin, 15, title)
    end
    return true
end

local function trackWithBlizzard(site, x, y)
    if not (C_Map and C_Map.GetUserWaypoint and C_Map.SetUserWaypoint and C_Map.ClearUserWaypoint
        and C_Map.CanSetUserWaypointOnMap and UiMapPoint and UiMapPoint.CreateFromCoordinates) then return false end
    if C_Map.GetUserWaypoint() or not C_Map.CanSetUserWaypointOnMap(site.map) then return false end
    C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(site.map, x, y))
    local saved = C_Map.GetUserWaypoint()
    if not saved or saved.uiMapID ~= site.map or not saved.position then return false end
    -- The game rounds the requested coordinates. Keep its values for the ownership check.
    nativePin = { map = saved.uiMapID, x = saved.position.x, y = saved.position.y }
    if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then
        C_SuperTrack.SetSuperTrackedUserWaypoint(true)
    end
    return true
end

local function placeMarker(frame)
    local canvas = frame:GetParent()
    if not markerSite or WorldMapFrame:GetMapID() ~= markerSite.map then
        frame.star:Hide()
        frame.label:Hide()
        return
    end
    local width, height = canvas:GetSize()
    frame:ClearAllPoints()
    frame:SetPoint("CENTER", canvas, "TOPLEFT", width * markerSite.x / 100, -height * markerSite.y / 100)
    frame.star:Show()
    frame.label:Show()
end

-- A separate map marker can coexist with a player's native pin, including a
-- RestedXP pin. Reposition our own frame when the visible map or its size changes.
local function trackOnMap(site)
    if not (WorldMapFrame and WorldMapFrame.GetCanvas and WorldMapFrame.GetMapID) then return false end
    local canvas = WorldMapFrame:GetCanvas()
    if not canvas then return false end
    if not marker then
        marker = CreateFrame("Frame", nil, canvas)
        marker:SetSize(20, 20)
        marker:SetFrameLevel(canvas:GetFrameLevel() + 80)
        marker.star = marker:CreateTexture(nil, "OVERLAY")
        marker.star:SetAllPoints()
        marker.star:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcon_1")
        marker.label = marker:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        marker:SetScript("OnUpdate", function(self, elapsed)
            self.elapsed = (self.elapsed or 0) + elapsed
            if self.elapsed >= 0.15 then
                self.elapsed = 0
                placeMarker(self)
            end
        end)
    end
    markerSite = site
    marker.label:SetText(site.name)
    marker.label:ClearAllPoints()
    if site.x > 65 then
        marker.label:SetPoint("RIGHT", marker, "LEFT", -2, 0)
    else
        marker.label:SetPoint("LEFT", marker, "RIGHT", 2, 0)
    end
    placeMarker(marker)
    marker:Show()
    return true
end

function A.ClearNavigation()
    if tomPin and TomTom and TomTom.RemoveWaypoint then TomTom:RemoveWaypoint(tomPin) end
    tomPin = nil
    if nativePin and C_Map and C_Map.GetUserWaypoint then
        local current = C_Map.GetUserWaypoint()
        local position = current and current.position
        if position and current.uiMapID == nativePin.map and position.x == nativePin.x and position.y == nativePin.y then
            C_Map.ClearUserWaypoint()
        end
    end
    nativePin, markerSite = nil, nil
    if marker then marker:Hide() end
end

function A.Navigate(siteKey, arrowOnly)
    local site = A.sites and A.sites[siteKey]
    if not site then return false end
    if type(site.map) ~= "number" or type(site.x) ~= "number" or type(site.y) ~= "number"
        or site.x < 0 or site.x > 100 or site.y < 0 or site.y > 100 then
        A.Print(site.name .. " — " .. (site.note or site.zone))
        return false
    end
    A.Print(string.format("%s — %s (%.1f, %.1f). %s", site.name, site.zone, site.x, site.y, site.note or ""))
    if InCombatLockdown and InCombatLockdown() then
        A.Print("Click the destination again after combat to mark the map.")
        return false
    end
    if C_Map and C_Map.GetMapInfo and not C_Map.GetMapInfo(site.map) then return false end
    A.ClearNavigation()
    local x, y = site.x / 100, site.y / 100
    if not arrowOnly and C_Map and C_Map.OpenWorldMap then C_Map.OpenWorldMap(site.map) end
    if trackWithTomTom(site,x,y) or trackWithBlizzard(site,x,y) then return true end
    if arrowOnly and C_Map and C_Map.OpenWorldMap then C_Map.OpenWorldMap(site.map) end
    return trackOnMap(site)
end
